// home.js — logika halaman Auto React (pengganti Home.jsx, vanilla JS).
//
// CATATAN: sekarang WAJIB login pakai Google (lihat window.RzoneAuth di
// common.js) sebelum fitur ini bisa dipakai — tidak ada lagi mode anonim.
// Tombol login sekarang link biasa ke /api/auth/google/start (full-page
// redirect), tidak perlu modal/polling seperti alur WhatsApp yang lama.
//
// Model react SEKARANG: jumlah reaksi yang muncul = jumlah SENDER AKTIF
// saat itu (tiap sender pilih 1 emoji acak dari daftar). Kalau tidak ada
// sender aktif, request ditolak server (lihat renderActiveSenderInfo()).
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const mainCard = document.getElementById("mainCard");
  const activeSenderText = document.getElementById("activeSenderText");

  function formatResetTime(iso) {
    if (!iso) return "00:01 WIB";
    try {
      return (
        new Date(iso).toLocaleString("id-ID", {
          timeZone: "Asia/Jakarta",
          hour: "2-digit",
          minute: "2-digit",
        }) + " WIB"
      );
    } catch {
      return "00:01 WIB";
    }
  }

  const form = document.getElementById("reactForm");
  const linkInput = document.getElementById("link");
  const emojiInput = document.getElementById("emojis");
  const submitBtn = document.getElementById("submitBtn");
  const preview = document.getElementById("preview");
  const previewEmojis = document.getElementById("previewEmojis");
  const errorBox = document.getElementById("errorBox");
  const errorText = document.getElementById("errorText");
  const successBox = document.getElementById("successBox");
  const successText = document.getElementById("successText");
  const quotaBox = document.getElementById("quotaBox");
  const quotaBlocks = document.getElementById("quotaBlocks");
  const quotaNote = document.getElementById("quotaNote");

  let quota = null; // { used, remaining, limit, resetAt }
  let activeSenderCount = 0;
  let controllerEnabled = false; // botrc di config.json

  // Sender WAJIB ada HANYA kalau controller (botrc) sedang mati -- kalau
  // botrc=true, controller dianggap sanggup jalan sendirian tanpa sender.
  function senderRequirementMet() {
    return activeSenderCount > 0 || controllerEnabled;
  }

  function renderActiveSenderInfo() {
    if (!activeSenderText) return;
    if (activeSenderCount > 0) {
      activeSenderText.textContent = `${activeSenderCount} sender sedang aktif`;
    } else if (controllerEnabled) {
      activeSenderText.textContent = "tidak ada sender aktif, tapi bot controller menyala";
    } else {
      activeSenderText.textContent = "TIDAK ADA sender aktif";
    }
    updateSubmitState();
  }

  function refreshActiveSenderCount() {
    fetch("/api/pairing/senders")
      .then((r) => r.json())
      .then((d) => {
        activeSenderCount = d.activeCount || 0;
        renderActiveSenderInfo();
      })
      .catch(() => {});
  }

  function refreshControllerEnabled() {
    fetch("/api/pairing/controller/status")
      .then((r) => r.json())
      .then((d) => {
        controllerEnabled = Boolean(d.enabled);
        renderActiveSenderInfo();
      })
      .catch(() => {});
  }

  function parseEmojis() {
    return [
      ...new Set(
        emojiInput.value
          .split(",")
          .map((e) => e.trim())
          .filter(Boolean)
      ),
    ];
  }

  function quotaExhausted() {
    return quota && quota.remaining <= 0;
  }

  function renderQuota() {
    if (!quota) {
      quotaBox.hidden = true;
      return;
    }
    quotaBox.hidden = false;
    quotaBlocks.innerHTML = "";
    for (let i = 0; i < quota.limit; i++) {
      const span = document.createElement("span");
      span.className = "nb-quota-block" + (i < quota.used ? " used" : "");
      quotaBlocks.appendChild(span);
    }
    quotaNote.textContent = quotaExhausted()
      ? `Habis — reset ${formatResetTime(quota.resetAt)}`
      : `Sisa ${quota.remaining}/${quota.limit} · reset 00:01 WIB`;

    updateSubmitState();
  }

  function updatePreview() {
    const emojis = parseEmojis();
    if (emojis.length > 0) {
      preview.hidden = false;
      previewEmojis.textContent = emojis.join(" ");
    } else {
      preview.hidden = true;
    }
    updateSubmitState();
  }

  function updateSubmitState() {
    const canSubmit =
      !quotaExhausted() &&
      senderRequirementMet() &&
      linkInput.value.trim() &&
      parseEmojis().length > 0;
    submitBtn.disabled = !canSubmit;
    if (quotaExhausted()) {
      submitBtn.textContent = "Jatah Hari Ini Habis";
    } else if (!senderRequirementMet()) {
      submitBtn.textContent = "Tidak Ada Sender Aktif";
    } else {
      submitBtn.textContent = "Tambahkan React";
    }
  }

  function showError(message) {
    errorText.textContent = message;
    errorBox.hidden = false;
  }

  function hideMessages() {
    errorBox.hidden = true;
    successBox.hidden = true;
  }

  function setLoading(loading) {
    submitBtn.disabled = loading || !!quotaExhausted() || !senderRequirementMet();
    if (loading) {
      submitBtn.innerHTML = '<span class="nb-spinner"></span> Memproses...';
    } else {
      updateSubmitState();
    }
  }

  emojiInput.addEventListener("input", updatePreview);
  linkInput.addEventListener("input", updateSubmitState);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideMessages();

    const link = linkInput.value.trim();
    const emojis = parseEmojis();

    if (!link) {
      showError("Isi link saluran WhatsApp Anda terlebih dahulu.");
      return;
    }
    if (emojis.length === 0) {
      showError("Isi minimal 1 emoji, pisahkan dengan koma.");
      return;
    }
    if (quotaExhausted()) {
      showError(`Jatah hari ini sudah habis. Coba lagi setelah ${formatResetTime(quota?.resetAt)}.`);
      return;
    }
    if (!senderRequirementMet()) {
      showError("Tidak ada sender WhatsApp yang aktif saat ini. Coba lagi nanti.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/react", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ link, emojis }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Gagal menambahkan react. Coba lagi.");
      }
      const successCount = data.result?.successCount ?? 0;
      const activeCount = data.result?.activeSenderCount ?? 0;
      successText.textContent = `Berhasil! ${successCount} dari ${activeCount} sender aktif berhasil mereaksi.`;
      successBox.hidden = false;
      linkInput.value = "";
      emojiInput.value = "";
      updatePreview();
      if (data.quota) {
        quota = data.quota;
        renderQuota();
      }
    } catch (err) {
      showError(err.message);
    } finally {
      setLoading(false);
    }
  });

  // Muat kuota saat halaman dibuka -- TAPI cek login dulu, karena
  // /api/react/status sekarang WAJIB sesi login (tidak ada mode anonim).
  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      mainCard.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    mainCard.hidden = false;

    refreshActiveSenderCount();
    refreshControllerEnabled();
    if (window.__rzoneSocket) {
      window.__rzoneSocket.on("sender:update", refreshActiveSenderCount);
      window.__rzoneSocket.on("sender:removed", refreshActiveSenderCount);
    }

    fetch("/api/react/status")
      .then((r) => r.json())
      .then((d) => {
        quota = d;
        renderQuota();
      })
      .catch(() => {});
  })();
})();
