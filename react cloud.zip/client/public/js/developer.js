// developer.js — logika halaman Developer.
// Login sekarang WAJIB pakai Google (lewat window.RzoneAuth di common.js).
// Tombol login sekarang link biasa (redirect penuh), tidak perlu handler
// klik JS sama sekali.
(function () {
  const loginGateCard = document.getElementById("loginGateCard");

  const authError = document.getElementById("authError");
  const authErrorText = document.getElementById("authErrorText");

  const apiKeyBox = document.getElementById("apiKeyBox");
  const apiKeyText = document.getElementById("apiKeyText");
  const emailText = document.getElementById("emailText");
  const copyKeyBtn = document.getElementById("copyKeyBtn");
  const regenBtn = document.getElementById("regenBtn");
  const regenHint = document.getElementById("regenHint");
  const logoutBtn = document.getElementById("logoutBtn");

  const limitStat = document.getElementById("limitStat");
  const limitHint = document.getElementById("limitHint");

  const dashboardCard = document.getElementById("dashboardCard");
  const statsLoadingText = document.getElementById("statsLoadingText");
  const statsContent = document.getElementById("statsContent");
  const usedTodayStat = document.getElementById("usedTodayStat");
  const remainingStat = document.getElementById("remainingStat");
  const totalStat = document.getElementById("totalStat");
  const historyEmpty = document.getElementById("historyEmpty");
  const historyTable = document.getElementById("historyTable");

  let apiKey = null;
  let regenConfirm = false;

  function formatTime(iso) {
    try {
      return (
        new Date(iso).toLocaleString("id-ID", {
          timeZone: "Asia/Jakarta",
          dateStyle: "medium",
          timeStyle: "short",
        }) + " WIB"
      );
    } catch {
      return iso;
    }
  }

  function showAuthError(message) {
    authErrorText.textContent = message;
    authError.hidden = false;
  }
  function hideAuthError() {
    authError.hidden = true;
  }

  function showApiKey(user) {
    loginGateCard.hidden = true;
    apiKeyBox.hidden = false;
    apiKey = user.apiKey;
    apiKeyText.textContent = apiKey;
    emailText.textContent = user.email;
  }

  copyKeyBtn.addEventListener("click", () => {
    if (!apiKey) return;
    navigator.clipboard?.writeText(apiKey).then(() => {
      copyKeyBtn.textContent = "Tersalin!";
      setTimeout(() => (copyKeyBtn.textContent = "Salin Key"), 1500);
    });
  });

  regenBtn.addEventListener("click", async () => {
    if (!regenConfirm) {
      regenConfirm = true;
      regenBtn.textContent = "Yakin? Klik lagi untuk konfirmasi";
      regenHint.hidden = false;
      return;
    }

    regenBtn.disabled = true;
    regenBtn.textContent = "Memproses...";
    hideAuthError();
    try {
      const res = await fetch("/api/dev/regenerate", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal membuat ulang API key.");
      apiKey = data.apiKey;
      apiKeyText.textContent = apiKey;
      loadStats();
    } catch (err) {
      showAuthError(err.message);
    } finally {
      regenBtn.disabled = false;
      regenBtn.textContent = "Buat Ulang API Key";
      regenHint.hidden = true;
      regenConfirm = false;
    }
  });

  logoutBtn.addEventListener("click", () => window.RzoneAuth.logout());

  function renderHistory(history) {
    historyTable.innerHTML = "";
    if (!history || history.length === 0) {
      historyEmpty.hidden = false;
      return;
    }
    historyEmpty.hidden = true;
    history.forEach((item) => {
      const row = document.createElement("div");
      row.style.display = "flex";
      row.style.justifyContent = "space-between";
      row.style.gap = "12px";
      row.style.padding = "8px 0";
      row.style.borderBottom = "1px solid var(--nb-border, #000)";
      row.style.fontSize = "13px";

      const linkSpan = document.createElement("span");
      linkSpan.style.wordBreak = "break-all";
      linkSpan.textContent = item.link;

      const timeSpan = document.createElement("span");
      timeSpan.style.whiteSpace = "nowrap";
      timeSpan.style.opacity = "0.7";
      timeSpan.textContent = formatTime(item.at);

      row.appendChild(linkSpan);
      row.appendChild(timeSpan);
      historyTable.appendChild(row);
    });
  }

  function loadStats() {
    dashboardCard.hidden = false;
    statsLoadingText.hidden = !statsContent.hidden ? true : false;
    if (statsContent.hidden) statsLoadingText.hidden = false;

    fetch("/api/dev/stats")
      .then((r) => r.json())
      .then((d) => {
        if (!d.ok) return;
        limitStat.textContent = `${d.quota.limit} / hari`;
        limitHint.textContent = d.quota.limit;
        usedTodayStat.textContent = `${d.quota.used}/${d.quota.limit}`;
        remainingStat.textContent = d.quota.remaining;
        totalStat.textContent = d.stats.totalRequests;
        renderHistory(d.history);
        statsContent.hidden = false;
      })
      .catch(() => {})
      .finally(() => {
        statsLoadingText.hidden = true;
      });
  }

  // Cek status login begitu halaman dibuka.
  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      apiKeyBox.hidden = true;
      dashboardCard.hidden = true;
      return;
    }
    showApiKey(user);
    loadStats();
  })();
})();
