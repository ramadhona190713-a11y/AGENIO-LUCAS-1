// account.js — logika halaman Account: profil, rincian limit API, dan
// redeem kode. Login WAJIB pakai Google (lihat window.RzoneAuth di
// common.js).
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const accountCard = document.getElementById("accountCard");
  const redeemCard = document.getElementById("redeemCard");

  const emailHeading = document.getElementById("emailHeading");
  const totalLimitStat = document.getElementById("totalLimitStat");
  const senderBonusStat = document.getElementById("senderBonusStat");
  const limitBreakdown = document.getElementById("limitBreakdown");

  const redeemInput = document.getElementById("redeemInput");
  const redeemBtn = document.getElementById("redeemBtn");
  const redeemError = document.getElementById("redeemError");
  const redeemErrorText = document.getElementById("redeemErrorText");
  const redeemSuccess = document.getElementById("redeemSuccess");
  const redeemSuccessText = document.getElementById("redeemSuccessText");

  const logoutBtn = document.getElementById("logoutBtn");

  function renderBreakdown(b) {
    if (!b) return;
    totalLimitStat.textContent = `${b.total}/hari`;
    senderBonusStat.textContent = `+${b.senderBonus}`;
    limitBreakdown.innerHTML = `
      <div style="display:flex; justify-content:space-between; padding:4px 0">
        <span>Limit dasar</span><b>${b.base}</b>
      </div>
      <div style="display:flex; justify-content:space-between; padding:4px 0">
        <span>Bonus sender aktif</span><b>+${b.senderBonus}</b>
      </div>
      <div style="display:flex; justify-content:space-between; padding:4px 0">
        <span>Bonus redeem/admin</span><b>+${b.redeemedBonus}</b>
      </div>
      <div style="display:flex; justify-content:space-between; padding:8px 0 0; margin-top:6px; border-top:2px solid var(--nb-ink); font-weight:900">
        <span>Total</span><span>${b.total}/hari</span>
      </div>
    `;
  }

  async function loadStats() {
    try {
      const res = await fetch("/api/dev/stats");
      const data = await res.json();
      if (!data.ok) return;
      renderBreakdown(data.limitBreakdown);
    } catch {
      // Diamkan -- kartu breakdown cukup tetap kosong kalau gagal muat.
    }
  }

  redeemBtn.addEventListener("click", async () => {
    redeemError.hidden = true;
    redeemSuccess.hidden = true;

    const code = redeemInput.value.trim();
    if (!code) {
      redeemErrorText.textContent = "Isi kode redeem dulu.";
      redeemError.hidden = false;
      return;
    }

    redeemBtn.disabled = true;
    redeemBtn.textContent = "Memproses...";
    try {
      const res = await fetch("/api/dev/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menukar kode.");

      redeemSuccessText.textContent = `Berhasil! +${data.addedLimit} limit API/hari. Total sekarang: ${data.newLimit}/hari.`;
      redeemSuccess.hidden = false;
      redeemInput.value = "";
      loadStats();
    } catch (err) {
      redeemErrorText.textContent = err.message;
      redeemError.hidden = false;
    } finally {
      redeemBtn.disabled = false;
      redeemBtn.textContent = "Tukar Kode";
    }
  });

  logoutBtn?.addEventListener("click", () => window.RzoneAuth.logout());

  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      accountCard.hidden = true;
      redeemCard.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    accountCard.hidden = false;
    redeemCard.hidden = false;
    emailHeading.textContent = user.email;
    loadStats();
  })();
})();
