// common.js — dipakai di semua halaman (index.html, pairing.html, developer.html).
// Menangani: highlight menu, buka/tutup drawer navigasi, DAN modul login
// (window.RzoneAuth) yang dipakai bersama home.js & developer.js.
//
// Login SEKARANG lewat Google (redirect halaman penuh ke
// /api/auth/google/start), BUKAN modal WhatsApp lagi -- jauh lebih
// sederhana karena tidak perlu polling status token sama sekali.

// common.js — dipakai di semua halaman (index.html, pairing.html,
// developer.html, account.html). Menangani: highlight menu navigasi BAWAH,
// indikator sender aktif, DAN modul login (window.RzoneAuth) yang dipakai
// bersama home.js, developer.js, account.js.
//
// Login lewat Google (redirect halaman penuh ke /api/auth/google/start).
// Navigasi SEKARANG di bawah layar (nb-bottom-nav), bukan drawer/hamburger
// samping lagi.

(function () {
  const path = window.location.pathname.replace(/\/index\.html$/, "/");

  document.querySelectorAll(".nb-bottom-nav a[href]").forEach((a) => {
    const href = a.getAttribute("href");
    const isActive = href === path || (href === "/" && path === "/");
    a.classList.toggle("active", isActive);
  });

  // === Indikator titik di navbar: sekarang menandakan ADA/TIDAKNYA
  // === sender publik yang aktif (bukan status controller lagi) --
  // === karena itu yang menentukan fitur react bisa dipakai atau tidak.
  const dots = document.querySelectorAll(".dot");

  function setActiveSenderIndicator(activeCount) {
    dots.forEach((dot) => {
      dot.classList.remove("on", "off");
      dot.classList.add(activeCount > 0 ? "on" : "off");
      dot.title = activeCount > 0 ? `${activeCount} sender aktif` : "Tidak ada sender aktif";
    });
  }

  fetch("/api/pairing/senders")
    .then((r) => r.json())
    .then((d) => setActiveSenderIndicator(d.activeCount || 0))
    .catch(() => {});

  if (window.io) {
    const socket = window.io("/", { path: "/socket.io" });
    // Setiap ada perubahan status sender mana pun, minta ulang ringkasan
    // jumlah aktif -- lebih sederhana & selalu akurat daripada
    // menghitung sendiri di banyak halaman berbeda.
    const refreshCount = () => {
      fetch("/api/pairing/senders")
        .then((r) => r.json())
        .then((d) => setActiveSenderIndicator(d.activeCount || 0))
        .catch(() => {});
    };
    socket.on("sender:update", refreshCount);
    socket.on("sender:removed", refreshCount);
    window.__rzoneSocket = socket; // dipakai bareng oleh pairing.js
  }

  // ===================================================================
  // === RzoneAuth — modul login (dipakai bersama index.html/home.js dan
  // === developer.html/developer.js).
  // ===================================================================
  let currentUser = null; // { email, apiKey } | null

  async function fetchMe() {
    try {
      const res = await fetch("/api/auth/me");
      if (!res.ok) {
        currentUser = null;
        return null;
      }
      currentUser = await res.json();
      return currentUser;
    } catch {
      currentUser = null;
      return null;
    }
  }

  function getUser() {
    return currentUser;
  }

  function loginUrl() {
    return "/api/auth/google/start";
  }

  async function logout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {}
    currentUser = null;
    window.location.reload();
  }

  window.RzoneAuth = { fetchMe, getUser, logout, loginUrl };
})();
