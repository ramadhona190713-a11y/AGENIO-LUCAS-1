// pairing.js — logika halaman Pairing, sekarang 2 bagian:
//   1. Pairing Bot Reactch (controller, opsional lewat config.json "botrc")
//   2. Add Sender Public (pool sender WhatsApp publik, tak terbatas)
(function () {
  // =========================== 1. CONTROLLER ===========================
  const controllerSection = document.getElementById("controllerSection");
  const statusBadge = document.getElementById("statusBadge");
  const checkingText = document.getElementById("checkingText");
  const notConnectedSection = document.getElementById("notConnectedSection");
  const getQrBtn = document.getElementById("getQrBtn");
  const waitingBox = document.getElementById("waitingBox");
  const qrBox = document.getElementById("qrBox");
  const qrImg = document.getElementById("qrImg");
  const errorBox = document.getElementById("errorBox");
  const errorText = document.getElementById("errorText");

  function showControllerError(message) {
    errorText.textContent = message;
    errorBox.hidden = false;
  }

  function renderControllerConnected() {
    // Sesuai spesifikasi: begitu controller TERHUBUNG, section ini
    // langsung disembunyikan total (tidak perlu ditampilkan lagi).
    controllerSection.hidden = true;
  }

  function renderControllerNeedsPairing() {
    controllerSection.hidden = false;
    checkingText.hidden = true;
    notConnectedSection.hidden = false;
    statusBadge.hidden = true;
  }

  async function initController() {
    try {
      const res = await fetch("/api/pairing/controller/status");
      const data = await res.json();

      if (!data.enabled) {
        // botrc=false -> section 1 disembunyikan total, tidak perlu apa-apa.
        controllerSection.hidden = true;
        return;
      }
      if (data.connected) {
        renderControllerConnected();
        return;
      }
      renderControllerNeedsPairing();
    } catch {
      controllerSection.hidden = true;
    }
  }

  getQrBtn?.addEventListener("click", async () => {
    errorBox.hidden = true;
    getQrBtn.disabled = true;
    waitingBox.hidden = false;
    try {
      const res = await fetch("/api/pairing/controller/qr", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal memulai pairing.");
      if (data.connected) {
        renderControllerConnected();
        return;
      }
      if (data.qr) {
        qrImg.src = data.qr;
        qrBox.hidden = false;
      }
    } catch (err) {
      showControllerError(err.message);
    } finally {
      waitingBox.hidden = true;
      getQrBtn.disabled = false;
    }
  });

  if (window.__rzoneSocket) {
    window.__rzoneSocket.on("controller:qr", (data) => {
      if (!data.qr) return;
      qrImg.src = data.qr;
      qrBox.hidden = false;
      waitingBox.hidden = true;
    });
    window.__rzoneSocket.on("controller:connected", (data) => {
      if (data.connected) renderControllerConnected();
    });
  }

  initController();

  // ========================= 2. SENDER PUBLIK =========================
  const activeSenderCountText = document.getElementById("activeSenderCountText");
  const addSenderBtn = document.getElementById("addSenderBtn");
  const senderLoginHint = document.getElementById("senderLoginHint");
  const addSenderForm = document.getElementById("addSenderForm");
  const methodButtons = document.querySelectorAll("#addSenderForm .nb-segment button");
  const phoneField = document.getElementById("phoneField");
  const senderPhoneInput = document.getElementById("senderPhone");
  const submitAddSenderBtn = document.getElementById("submitAddSenderBtn");
  const addSenderError = document.getElementById("addSenderError");
  const addSenderErrorText = document.getElementById("addSenderErrorText");
  const senderListEmpty = document.getElementById("senderListEmpty");
  const senderList = document.getElementById("senderList");

  let currentMethod = "qr";
  let isLoggedIn = false;
  const sendersMap = new Map(); // id -> sender data (termasuk field isMine dari server)

  // Menambahkan sender WAJIB login (Google) -- kalau belum, tombol ini
  // mengarahkan ke login, bukan membuka form.
  addSenderBtn?.addEventListener("click", () => {
    if (!isLoggedIn) {
      window.location.href = "/api/auth/google/start";
      return;
    }
    addSenderForm.hidden = !addSenderForm.hidden;
    addSenderError.hidden = true;
  });

  methodButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      methodButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentMethod = btn.dataset.method;
      phoneField.hidden = currentMethod !== "pairing";
    });
  });

  function statusLabel(status) {
    switch (status) {
      case "connected":
        return "🟢 Aktif";
      case "qr":
        return "🟡 Menunggu scan QR";
      case "waiting_pairing_code":
        return "🟡 Menunggu kode dimasukkan";
      case "connecting":
        return "⏳ Menyambungkan...";
      case "disconnected":
        return "🔴 Terputus (mencoba lagi)";
      case "error":
        return "❌ Gagal";
      default:
        return status;
    }
  }

  function renderSenderList() {
    const items = Array.from(sendersMap.values());
    activeSenderCountText.textContent = items.filter((s) => s.status === "connected").length;

    if (items.length === 0) {
      senderListEmpty.hidden = false;
      senderList.innerHTML = "";
      return;
    }
    senderListEmpty.hidden = true;

    senderList.innerHTML = "";
    items.forEach((s) => {
      const card = document.createElement("div");
      card.className = "nb-card";
      card.style.marginBottom = "10px";
      card.style.padding = "12px";

      const head = document.createElement("div");
      head.style.display = "flex";
      head.style.justifyContent = "space-between";
      head.style.alignItems = "center";
      head.style.gap = "8px";

      const label = document.createElement("span");
      label.innerHTML = `<b>${s.phoneNumber || s.label || s.id}</b><br><span style="font-size:13px">${statusLabel(
        s.status
      )}</span>`;

      const removeBtn = document.createElement("button");
      removeBtn.className = "nb-btn sm";
      removeBtn.textContent = "Hapus";
      removeBtn.addEventListener("click", () => removeSender(s.id));

      head.appendChild(label);
      // Tombol "Hapus" HANYA ditampilkan untuk sender milik sendiri --
      // izin sesungguhnya tetap dicek ulang di server (DELETE endpoint),
      // ini murni supaya orang lain tidak disuguhi tombol yang percuma.
      if (s.isMine) head.appendChild(removeBtn);
      card.appendChild(head);

      if (s.status === "qr" && s.qr) {
        const qrWrap = document.createElement("div");
        qrWrap.className = "nb-qr-box";
        qrWrap.style.marginTop = "10px";
        qrWrap.innerHTML = `<img src="${s.qr}" alt="QR sender" style="max-width:200px" /><p>Scan pakai WhatsApp &gt; Perangkat Tertaut</p>`;
        card.appendChild(qrWrap);
      }

      if (s.status === "waiting_pairing_code" && s.pairingCode) {
        const codeWrap = document.createElement("div");
        codeWrap.className = "nb-alert nb-alert-info";
        codeWrap.style.marginTop = "10px";
        codeWrap.innerHTML = `<span class="icon">🔢</span><span>Kode: <b style="letter-spacing:2px">${s.pairingCode}</b><br>Masukkan di HP: WhatsApp &gt; Perangkat Tertaut &gt; Tautkan dengan nomor telepon.</span>`;
        card.appendChild(codeWrap);
      }

      if (s.status === "error" && s.error) {
        const errWrap = document.createElement("div");
        errWrap.className = "nb-alert nb-alert-error";
        errWrap.style.marginTop = "10px";
        errWrap.innerHTML = `<span class="icon">⚠️</span><span>${s.error}</span>`;
        card.appendChild(errWrap);
      }

      senderList.appendChild(card);
    });
  }

  async function removeSender(id) {
    try {
      const res = await fetch(`/api/pairing/senders/${encodeURIComponent(id)}`, { method: "DELETE" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        alert(data.error || "Gagal menghapus sender.");
        return;
      }
      sendersMap.delete(id);
      renderSenderList();
    } catch {
      alert("Gagal menghapus sender. Coba lagi.");
    }
  }

  submitAddSenderBtn?.addEventListener("click", async () => {
    addSenderError.hidden = true;
    const phoneNumber = senderPhoneInput.value.trim();

    if (currentMethod === "pairing" && !phoneNumber) {
      addSenderErrorText.textContent = "Isi nomor WhatsApp terlebih dahulu.";
      addSenderError.hidden = false;
      return;
    }

    submitAddSenderBtn.disabled = true;
    submitAddSenderBtn.textContent = "Menghubungkan...";
    try {
      const res = await fetch("/api/pairing/senders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: currentMethod, phoneNumber: phoneNumber || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menambahkan sender.");

      sendersMap.set(data.sender.id, data.sender);
      renderSenderList();
      senderPhoneInput.value = "";
      addSenderForm.hidden = true;
    } catch (err) {
      addSenderErrorText.textContent = err.message;
      addSenderError.hidden = false;
    } finally {
      submitAddSenderBtn.disabled = false;
      submitAddSenderBtn.textContent = "Hubungkan";
    }
  });

  // Socket cuma dipakai sebagai SINYAL "ada yang berubah" -- data
  // sesungguhnya (termasuk field `isMine`, yang berbeda per orang yang
  // sedang login) selalu diambil ulang lewat GET /api/pairing/senders,
  // supaya tidak pernah salah menampilkan/menyembunyikan tombol "Hapus".
  if (window.__rzoneSocket) {
    window.__rzoneSocket.on("sender:update", () => initSenders());
    window.__rzoneSocket.on("sender:removed", ({ id }) => {
      sendersMap.delete(id);
      renderSenderList();
    });
  }

  async function initSenders() {
    try {
      const res = await fetch("/api/pairing/senders");
      const data = await res.json();
      sendersMap.clear();
      (data.senders || []).forEach((s) => sendersMap.set(s.id, s));
      renderSenderList();
    } catch {
      renderSenderList();
    }
  }

  (async function initSenderSection() {
    const user = await window.RzoneAuth.fetchMe();
    isLoggedIn = Boolean(user && user.ok);
    senderLoginHint.hidden = isLoggedIn;
    await initSenders();
  })();
})();
