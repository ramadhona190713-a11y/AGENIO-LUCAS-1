# Rzone WA Bot

Website + Bot WhatsApp (pairing via QR code) dengan fitur auto-react link
saluran, tema UI **neobrutalism**, dan mode developer (API key + limit
harian).

## Struktur Proyek

```
rzone-wa-bot/
├── server/     -> Backend Node.js (Express + Baileys + Socket.io)
└── client/     -> Frontend statis (HTML + CSS + JS biasa, tanpa React/build tool)
```

Semuanya jalan di **satu port: `http://localhost:3000`** — Express men-serve
API sekaligus file statis di `client/public`, jadi tidak perlu 2 server
terpisah dan **tidak ada proses build** untuk frontend.

## Cara Cepat (dari root folder)

```bash
npm run setup   # install dependency server saja (client tidak butuh install/build)
npm start       # jalankan server di http://localhost:3000
```

## Cara Manual (kalau mau lebih detail)

### 1. Frontend

Tidak ada langkah build. `client/public/` sudah berisi HTML/CSS/JS jadi
(`index.html`, `pairing.html`, `developer.html`, dll) yang langsung
disajikan apa adanya oleh server Express — edit filenya langsung kalau mau
mengubah tampilan, tidak perlu `npm install` atau `npm run build` di folder
client.

### 2. Jalankan Backend (sekaligus serve frontend)

```bash
cd server
npm install
```

Edit `server/config.json` sesuai kebutuhan:

```json
{
  "port": 3000,
  "cloudflaredTunnelToken": "TARUH_TOKEN_CLOUDFLARED_KAMU_DISINI",
  ...
}
```

Jalankan server:

```bash
npm start
```

Buka `http://localhost:3000` — halaman web, API, dan koneksi WhatsApp semua
lewat port ini. Saat pertama kali jalan, belum ada sesi WhatsApp — buka
halaman `/pairing` untuk scan QR.

## 3. Setup Cloudflared Tunnel (auto-start bareng `npm start`)

**Sekarang tidak perlu jalankan cloudflared secara terpisah lagi** — server
otomatis menjalankannya sebagai child process begitu `npm start` dipanggil,
selama `cloudflaredTunnelToken` di `config.json` sudah diisi.

1. Install `cloudflared` dan pastikan ada di PATH sistem:
   ```bash
   # Ubuntu/Debian
   curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
   sudo dpkg -i cloudflared.deb
   ```
   (Windows/Mac: pakai installer dari situs resmi Cloudflare)

2. Buat tunnel & ambil token-nya:
   ```bash
   cloudflared tunnel login
   cloudflared tunnel create rzone-bot
   cloudflared tunnel token rzone-bot
   ```

3. Taruh token itu di `server/config.json`:
   ```json
   { "cloudflaredTunnelToken": "TOKEN_HASIL_LANGKAH_2" }
   ```

4. Jalankan seperti biasa:
   ```bash
   npm start
   ```
   Server DAN tunnel akan jalan bareng dari satu perintah ini. Kalau token
   belum diisi (masih placeholder), server tetap jalan normal tapi tunnel
   tidak di-start otomatis — ada log peringatan di terminal.

5. Kalau mau tunnel-nya nyambung ke domain sendiri (misal
   `bot.domainkamu.com`), atur di dashboard Cloudflare Zero Trust → Tunnels
   → routing ke `http://localhost:3000`.

Untuk mematikan server + tunnel, cukup `Ctrl+C` di terminal — keduanya akan
dimatikan dengan rapi bersamaan.

## 5. Login Wajib Pakai Google

**Tidak ada lagi mode anonim/tamu**, dan **login sekarang lewat Google**
(bukan WhatsApp lagi) — alasannya: nomor WhatsApp gampang dibuat berkali-kali
(SIM baru/nomor virtual) untuk menghindari limit harian, sedangkan akun
Google jauh lebih tidak praktis dibuat massal.

### Cara setup Google OAuth (WAJIB sebelum login bisa dipakai)

1. Buka [Google Cloud Console](https://console.cloud.google.com/) → buat
   project baru (atau pakai yang sudah ada).
2. Buka menu **APIs & Services → OAuth consent screen**:
   - User Type: **External** (kecuali kamu pakai Google Workspace sendiri).
   - Isi nama aplikasi, email support, dsb (boleh asal-asalan untuk testing,
     tapi kalau mau publik sebaiknya diisi wajar).
   - Scopes: cukup default (`email`, `profile`, `openid`) — tidak perlu
     tambah apa-apa.
   - Test users: kalau app masih status "Testing", **tambahkan email Google
     kamu sendiri di sini**, kalau tidak nanti muncul error "access blocked"
     saat mencoba login sendiri.
3. Buka menu **APIs & Services → Credentials → Create Credentials → OAuth
   client ID**:
   - Application type: **Web application**.
   - Authorized redirect URIs, isi PERSIS:
     ```
     https://domain-tunnel-kamu.trycloudflare.com/api/auth/google/callback
     ```
     (ganti sesuai `publicBaseUrl` kamu — harus sama persis, termasuk
     `https://` dan tanpa garis miring tambahan di akhir).
   - Klik **Create** → Google akan menampilkan **Client ID** dan
     **Client Secret**. Simpan keduanya.
4. Taruh di `server/config.json` (2 key baru, ditambahkan manual — sengaja
   TIDAK diisi otomatis):
   ```json
   {
     "publicBaseUrl": "https://domain-tunnel-kamu.trycloudflare.com",
     "googleClientId": "xxxxxxxxxx.apps.googleusercontent.com",
     "googleClientSecret": "GOCSPX-xxxxxxxxxxxxxxxxxxxx"
   }
   ```
   - `publicBaseUrl` — kalau kamu sudah pakai fitur ini sebelumnya (versi
     WhatsApp login), key ini mungkin sudah ada, tinggal dipastikan masih
     sesuai domain tunnel yang aktif sekarang.
   - Kalau alamat websitenya SERING BERGANTI (mis. tunnel Cloudflare gratis
     yang domainnya acak tiap restart), kamu perlu update juga Authorized
     redirect URI di Google Cloud Console setiap kali domain berubah — atau
     pakai domain tetap (Cloudflare Tunnel custom domain / VPS dengan
     domain sendiri) supaya tidak perlu bolak-balik update.
5. Restart server. Tombol **"Login dengan Google"** di web akan langsung
   berfungsi begitu 2 key di atas terisi benar.

Setiap akun Google yang berhasil login otomatis dapat 1 akun + 1 API key,
dengan dua kuota harian yang independen:

- **Kuota web** (`/api/react`) — default **2x/hari**, dikonfigurasi lewat
  `config.json` -> `reactMode.dailyLimitPerIp` (nama key dipertahankan dari
  versi lama, sekarang artinya "per akun Google").
- **Kuota API** (`/api/dev/react`) — default **10x/hari**, dikonfigurasi
  lewat `config.json` -> `developerMode.dailyLimitPerApiKey`.

**Ganti nilai default di `config.json`** untuk `developerMode.jwtSecret`
(dipakai menandatangani cookie sesi login) dengan string acak yang panjang &
unik sebelum dipakai serius.

> Catatan jujur: akun Google jauh lebih sulit dibuat massal dibanding nomor
> WhatsApp, tapi tetap TIDAK ADA jaminan 100% — orang yang sangat
> determinasi tetap bisa membuat beberapa akun Google. Yang bisa dijamin di
> level kode: kuota per akun tidak bisa ditembus dari akun yang sama.

## 6. Mode Reaksi: Controller (opsional) + Pool Sender Publik

Ini bagian yang berubah paling besar. Sekarang ada **dua mekanisme reaksi**
yang bisa berjalan bersamaan:

### a) Pool Sender Publik (utama, WAJIB ada minimal 1 aktif)

Di halaman `/pairing`, bagian **"2. Add Sender Public"**, **siapa pun** bisa
menghubungkan nomor WhatsApp-nya sendiri sebagai "sender" — **jumlahnya
tidak dibatasi**. Setiap kali ada request react masuk (dengan beberapa
emoji sekaligus), **SETIAP sender yang sedang aktif memilih SATU emoji
secara ACAK** dari daftar itu, lalu mereaksi pesan targetnya sendiri-sendiri.

Jadi kalau ada 5 sender aktif dan kamu minta emoji `🔥,❤️,😂`, pesan target
akan mendapat **5 reaksi** (masing-masing sender pilih 1 dari 3 emoji itu
secara acak) — meniru banyak akun asli yang bereaksi secara natural.

**Kalau tidak ada sender aktif sama sekali, request DITOLAK** (tidak
diproses, kuota juga tidak ikut terpakai) — makanya di halaman Home ada
keterangan jumlah sender aktif.

Ada 2 cara menghubungkan sender:
- **Scan QR** — sama seperti pairing WhatsApp Web biasa.
- **Kode Pairing** — masukkan nomor WhatsApp, sistem akan **benar-benar
  meminta kode pairing asli ke server WhatsApp** (lewat
  `sock.requestPairingCode()` bawaan Baileys, BUKAN kode buatan sendiri),
  lalu kode itu dimasukkan di HP: WhatsApp → Perangkat Tertaut → Tautkan
  dengan nomor telepon.

Sender yang sudah pernah dipasang **otomatis tersambung ulang** setiap
server restart (tidak perlu scan/pairing ulang), kecuali kamu logout nomor
itu dari HP-nya langsung atau menghapusnya lewat tombol "Hapus" di daftar
sender.

### b) Bot Controller / "Pairing Bot Reactch" (opsional, `botrc`)

Ini mekanisme LAMA: satu nomor bot mengetik command
`.reactch <link> <emoji,emoji>` ke grup, lalu mereaksi berurutan untuk
SEMUA emoji yang diminta (bukan cuma 1 acak). Sekarang **sepenuhnya
opsional**, dikontrol lewat `config.json`:

```json
{ "botrc": false }
```

- `botrc: false` (default aman) → controller ini **sama sekali tidak
  dijalankan**, tidak perlu pairing apa pun. Section
  **"1. Pairing Bot Reactch"** di halaman `/pairing` **otomatis
  disembunyikan total**. Reaksi murni mengandalkan pool sender publik (poin
  a di atas).
- `botrc: true` → controller **aktif**, section pairing-nya muncul kalau
  belum tersambung (untuk scan QR-nya). **Begitu sudah tersambung, section
  itu ikut disembunyikan lagi** (tidak perlu ditampilkan terus). Setiap ada
  request react masuk, controller ini menambahkan REAKSI EKSTRA di luar
  reaksi para sender publik.

`botrc` **tidak diisi otomatis** ke `config.json` (sesuai permintaan) —
tambahkan manual barisnya kalau mau mengaktifkan controller.

### Antrian (spacing) — tetap/"normal" di kode, TIDAK dikonfigurasi lewat config.json

- Reaksi dari **controller** (kalau `botrc: true`): jarak minimal **10
  detik** antar eksekusi `.reactch` — melindungi SATU nomor controller dari
  flood command ke grup.
- Reaksi dari **sender publik**: jarak minimal **1.2 detik** antar reaksi
  (beda nomor per reaksi, jadi risiko limit per-nomor jauh lebih kecil,
  tapi tetap diberi jeda supaya tidak "meledak" bersamaan dalam hitungan
  milidetik di satu pesan).

## 7. Bot Telegram Admin (opsional)

Untuk memudahkan kelola akun developer & pantau sender tanpa perlu buka
File Manager/SFTP tiap kali, ada bot Telegram khusus admin:

- `/accounts` — daftar semua akun developer, limit harian, & pemakaian
- `/account <email>` — detail 1 akun + 5 link terakhir yang direact
- `/setlimit <email> <angka>` — ubah limit harian custom akun tertentu
- `/resetlimit <email>` — kembalikan ke limit default
- `/senders` — jumlah & daftar sender WhatsApp publik yang sedang aktif

**Setup:**

1. Buat bot lewat [@BotFather](https://t.me/BotFather) di Telegram, ambil
   token-nya.
2. Cari tahu chat ID Telegram kamu sendiri (mis. lewat bot
   [@userinfobot](https://t.me/userinfobot)).
3. Isi `server/config.json`:
   ```json
   "telegramBot": {
     "enabled": true,
     "botToken": "TOKEN_DARI_BOTFATHER",
     "adminChatIds": [123456789]
   }
   ```
4. Restart server (`npm start`). Kalau `enabled: false` atau token/chat ID
   kosong, bot ini otomatis tidak aktif.

Bot ini **hanya merespons chat ID yang ada di `adminChatIds`** — pesan dari
siapa pun/chat lain diabaikan total tanpa balasan apa pun, dan API key tidak
pernah dikirim utuh lewat Telegram (selalu disamarkan).

## 8. Alur Pemakaian Lengkap

1. Jalankan server, lalu jalankan cloudflared tunnel supaya web bisa
   diakses lewat internet.
2. Setup Google OAuth (bagian 5) supaya login berfungsi.
3. Buka `/pairing` → di bagian **"Add Sender Public"**, tambahkan minimal
   1 sender (scan QR atau kode pairing). Kalau mau, aktifkan juga
   controller lewat `botrc: true` + pairing QR-nya.
4. Buka halaman **Home** → login dengan Google → masukkan link saluran +
   emoji (pisah koma) → klik **Tambahkan React**.
5. Server menolak request kalau tidak ada sender aktif, atau kalau kuota
   harian akun kamu sudah habis. Kalau lolos, setiap sender aktif
   (+ controller kalau aktif) mereaksi pesan yang mengandung link tsb.
6. Mode **Developer**: login dengan Google (sama seperti di atas) untuk
   dapat API key (limit 10 request/hari default). Model reaksinya SAMA
   dengan web (sender pool + controller opsional). Dokumentasi lengkap:
   `server/DEVELOPER_API.md`.

## Catatan Penting

- Ini scaffold/starter project, bukan produk siap produksi. Akun, kuota,
  dan daftar sender disimpan di file JSON tersinkron disk (`db.js`,
  synchronous + atomik lewat rename file, TANPA dependency native apa pun
  supaya tidak gagal install di hosting terbatas seperti Pterodactyl), tapi
  riwayat pesan grup untuk pencarian link (`messageStore.js`) masih murni
  di memori per akun WhatsApp — hilang kalau server di-restart (sender/
  controller perlu "melihat ulang" pesan di grupnya lagi setelah restart).
- Menggunakan **Baileys**, library WhatsApp Web tidak resmi. Pemakaian untuk
  otomasi massal (termasuk pool sender publik tak terbatas) berisiko
  melanggar Ketentuan Layanan WhatsApp dan berujung nomor diblokir —
  gunakan dengan bijak, dan pertimbangkan risikonya sebelum membuka fitur
  "Add Sender Public" untuk umum.
- Login sekarang **wajib** dan **hanya** lewat Google (lihat bagian 5) —
  jangan lupa isi `config.json` -> `publicBaseUrl`, `googleClientId`, dan
  `googleClientSecret` sebelum deploy, atau tombol login akan menampilkan
  pesan error yang jelas (bukan gagal diam-diam).
