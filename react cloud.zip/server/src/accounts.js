/**
 * Manajemen akun — SEKARANG identitas akun adalah EMAIL GOOGLE (bukan
 * nomor WhatsApp lagi -- lihat googleAuth.js untuk alasannya). Tiap akun
 * Google yang berhasil login otomatis:
 *   - dapat 1 akun (dibuat otomatis kalau belum ada, sekali per email),
 *   - dapat 1 API key otomatis,
 *   - dua kuota harian yang TERPISAH & independen:
 *       kind='web' -> dipakai endpoint /api/react (default 2x/hari)
 *       kind='api' -> dipakai endpoint /api/dev/react (default 10x/hari)
 *
 * Semua operasi baca-ubah-tulis di sini SYNCHRONOUS (lihat db.js) --
 * cek+tambah kuota tetap atomik walau tidak pakai database sungguhan.
 */

const crypto = require("crypto");
const db = require("./db");

const WIB_OFFSET_MS = 7 * 60 * 60 * 1000; // UTC+7

function periodKey(date = new Date()) {
  return new Date(date.getTime() + WIB_OFFSET_MS).toISOString().slice(0, 10);
}

function generateApiKey() {
  return "rzone_" + crypto.randomBytes(24).toString("hex");
}

function maskApiKey(apiKey) {
  if (!apiKey || apiKey.length < 14) return "****";
  return `${apiKey.slice(0, 10)}...${apiKey.slice(-4)}`;
}

/**
 * Cari akun berdasar email Google, atau buat baru kalau belum pernah
 * login. Synchronous & tanpa `await` di tengah -> tidak mungkin dua
 * request untuk email yang sama nyaris bersamaan membuat 2 akun berbeda.
 */
function findOrCreateByEmail(email, googleSub) {
  const existing = db.findUserByEmail(email);
  if (existing) return existing;
  return db.createUser(email, googleSub, generateApiKey());
}

function findByApiKey(apiKey) {
  return db.findUserByApiKey(apiKey);
}

function findById(id) {
  return db.findUserById(id);
}

/**
 * Cek & catat 1 pemakaian. Kalau kuota sudah habis, melempar error
 * SEBELUM apa pun ditambahkan -- jadi tidak ada kemungkinan
 * "kepotong tapi ditolak".
 */
function checkAndConsume(userId, kind, dailyLimit) {
  const period = periodKey();
  const used = db.getUsageCount(userId, kind, period);
  if (used >= dailyLimit) {
    const err = new Error(
      `Limit ${dailyLimit}x/hari untuk fitur ini sudah tercapai. Coba lagi setelah reset jam 00:01 WIB.`
    );
    err.code = "LIMIT_REACHED";
    throw err;
  }
  const newUsed = db.incrementUsage(userId, kind, period);
  return { used: newUsed, remaining: Math.max(0, dailyLimit - newUsed), limit: dailyLimit };
}

function getUsage(userId, kind, dailyLimit) {
  const period = periodKey();
  const used = db.getUsageCount(userId, kind, period);
  return { used, remaining: Math.max(0, dailyLimit - used), limit: dailyLimit };
}

function recordLog(userId, kind, link) {
  db.addLog(userId, kind, link);
}

/** Riwayat pemakaian 1 akun untuk 1 jenis kuota (dipakai dashboard Developer). */
function getRecentLog(userId, kind, limit = 50) {
  return db.recentLogs(userId, kind, limit);
}

/**
 * Limit 'web' -- tetap sesederhana dulu: custom per-akun atau default.
 * Limit 'api' -- SEKARANG dirakit dari 3 komponen (lihat resolveApiLimit):
 *   base + bonus sender aktif + bonus redeem/broadcast admin.
 */
function resolveLimit(user, kind, defaultLimit) {
  if (kind === "api") return resolveApiLimit(user, defaultLimit);
  const custom = user.daily_limit_web;
  return typeof custom === "number" && custom > 0 ? custom : defaultLimit;
}

/**
 * base:
 *   1. daily_limit_api custom per-akun (di-set admin lewat /setlimit), atau
 *   2. globalPublicApiLimit (di-set admin lewat /setpublik, berlaku ke
 *      SEMUA akun yang tidak punya custom limit), atau
 *   3. default dari config.json.
 * ditambah:
 *   - bonus_active_senders: +1 tiap sender MILIK akun ini yang sedang
 *     konek & bertahan, -2 tiap kali salah satu putus (lihat senderPool.js)
 *   - redeemed_limit_api: dari kode redeem (/crd Telegram) + broadcast
 *     admin (/al Telegram), permanen sampai direset manual.
 */
function resolveApiLimit(user, defaultLimit) {
  const hasCustom = typeof user.daily_limit_api === "number" && user.daily_limit_api > 0;
  const base = hasCustom ? user.daily_limit_api : db.getGlobalPublicApiLimit() ?? defaultLimit;
  const senderBonus = user.bonus_active_senders || 0;
  const redeemedBonus = user.redeemed_limit_api || 0;
  return base + senderBonus + redeemedBonus;
}

/** Rincian limit API, dipakai untuk ditampilkan di halaman Account/Developer. */
function getApiLimitBreakdown(user, defaultLimit) {
  const hasCustom = typeof user.daily_limit_api === "number" && user.daily_limit_api > 0;
  const base = hasCustom ? user.daily_limit_api : db.getGlobalPublicApiLimit() ?? defaultLimit;
  const senderBonus = user.bonus_active_senders || 0;
  const redeemedBonus = user.redeemed_limit_api || 0;
  return { base, senderBonus, redeemedBonus, total: base + senderBonus + redeemedBonus };
}

/** Dipanggil senderPool.js begitu 1 sender milik akun ini berhasil konek. */
function addSenderConnectBonus(userId) {
  db.adjustSenderBonus(userId, 1);
}

/** Dipanggil senderPool.js begitu 1 sender milik akun ini putus koneksi. */
function addSenderDisconnectPenalty(userId) {
  db.adjustSenderBonus(userId, -2);
}

/** Redeem 1 kode (dibuat admin lewat /crd di Telegram) untuk akun ini. */
function redeemCode(code, userId) {
  return db.redeemCode(code, userId);
}

function regenerateApiKey(userId) {
  const newKey = generateApiKey();
  db.updateUserApiKey(userId, newKey);
  return newKey;
}

/** Total react (semua user & kind) hari ini WIB -- dipakai /reacthariini di Telegram. */
function getTodayReactCount() {
  return db.countLogsInPeriod(periodKey());
}

/** Ranking user paling banyak react hari ini WIB -- dipakai /leaderboard di Telegram. */
function getTodayLeaderboard(limit = 10) {
  return db.leaderboardInPeriod(periodKey(), limit);
}

// ===================================================================
// Fungsi khusus ADMIN (dipanggil dari telegramBot.js saja).
// ===================================================================

function listAccountsSummary(defaultApiLimit) {
  const period = periodKey();
  return db.allUsers().map((u) => ({
    email: u.email,
    apiKeyMasked: maskApiKey(u.api_key),
    dailyLimit: resolveLimit(u, "api", defaultApiLimit),
    isCustomLimit: typeof u.daily_limit_api === "number" && u.daily_limit_api > 0,
    usedToday: db.getUsageCount(u.id, "api", period),
    totalRequests: db.countLogs(u.id),
  }));
}

function findAccountDetail(email, defaultApiLimit) {
  const u = db.findUserByEmail(email);
  if (!u) return null;
  const period = periodKey();
  return {
    email: u.email,
    apiKeyMasked: maskApiKey(u.api_key),
    dailyLimit: resolveLimit(u, "api", defaultApiLimit),
    isCustomLimit: typeof u.daily_limit_api === "number" && u.daily_limit_api > 0,
    usedToday: db.getUsageCount(u.id, "api", period),
    totalRequests: db.countLogs(u.id),
    recentLinks: db.recentLogs(u.id, "api", 5),
  };
}

function setDailyLimitByEmail(email, newLimit) {
  if (!Number.isFinite(newLimit) || newLimit <= 0) {
    throw new Error("Limit harus berupa angka lebih dari 0.");
  }
  const user = db.findUserByEmail(email);
  if (!user) throw new Error("Akun tidak ditemukan.");
  db.setUserLimit(email, "api", Math.floor(newLimit));
  return { email, dailyLimit: Math.floor(newLimit) };
}

function clearDailyLimitByEmail(email) {
  const user = db.findUserByEmail(email);
  if (!user) throw new Error("Akun tidak ditemukan.");
  db.clearUserLimit(email, "api");
  return { email };
}

/**
 * Redeem code, dipakai admin memberi bonus limit API lewat kode yang bisa
 * ditukar user sendiri di web (lihat routes/dev.js -> POST /redeem).
 */
function createRedeemCode(code, limitAmount, usageQuota) {
  if (!code || typeof code !== "string") throw new Error("Kode wajib diisi.");
  if (!Number.isFinite(limitAmount) || limitAmount <= 0) {
    throw new Error("Jumlah limit yang didapat harus angka > 0.");
  }
  if (!Number.isFinite(usageQuota) || usageQuota <= 0) {
    throw new Error("Jumlah kuota pemakaian harus angka > 0.");
  }
  db.createRedeemCode(code, Math.floor(limitAmount), Math.floor(usageQuota));
  return { code, limitAmount: Math.floor(limitAmount), usageQuota: Math.floor(usageQuota) };
}

/** Broadcast bonus limit API PERMANEN ke SEMUA akun yang ada saat ini. */
function broadcastBonusToAll(amount) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Jumlah harus angka > 0.");
  const affectedCount = db.addBonusToAllUsers(Math.floor(amount));
  return { amount: Math.floor(amount), affectedCount };
}

/** Ubah limit API DASAR publik untuk semua akun yang tidak punya custom limit. */
function setGlobalPublicLimit(amount) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Jumlah harus angka > 0.");
  db.setGlobalPublicApiLimit(Math.floor(amount));
  return { amount: Math.floor(amount) };
}

module.exports = {
  findOrCreateByEmail,
  findByApiKey,
  findById,
  checkAndConsume,
  getUsage,
  recordLog,
  getRecentLog,
  resolveLimit,
  getApiLimitBreakdown,
  addSenderConnectBonus,
  addSenderDisconnectPenalty,
  redeemCode,
  createRedeemCode,
  broadcastBonusToAll,
  setGlobalPublicLimit,
  regenerateApiKey,
  getTodayReactCount,
  getTodayLeaderboard,
  maskApiKey,
  listAccountsSummary,
  findAccountDetail,
  setDailyLimitByEmail,
  clearDailyLimitByEmail,
};
