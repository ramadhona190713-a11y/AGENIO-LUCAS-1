/**
 * Lapisan database — JSON tersinkron ke disk, tanpa dependency native
 * apa pun (murni pakai `fs` bawaan Node). Didesain aman meski "cuma" JSON:
 *
 * 1. SEMUA fungsi di bawah ini SYNCHRONOUS, tanpa `await` di
 *    tengah-tengah baca-ubah-tulis. Karena Node.js single-threaded, ini
 *    membuat setiap operasi otomatis ATOMIK dari sudut pandang request
 *    lain -- tidak mungkin dua request "lolos" kuota di detik yang sama.
 * 2. File ditulis lewat pola "tulis ke file sementara, lalu rename"
 *    (`fs.renameSync`), yang di hampir semua filesystem bersifat atomik --
 *    kalau proses mati mendadak di tengah penulisan, file database yang
 *    LAMA tetap utuh, tidak pernah ada file yang "setengah jadi"/korup.
 * 3. File database (`data/rzone-db.json`) TIDAK PERNAH disajikan lewat
 *    static file server, jadi tidak mungkin "bocor" lewat URL langsung.
 *
 * Identitas akun berbasis EMAIL GOOGLE -- lihat googleAuth.js & accounts.js.
 *
 * Komponen limit API harian SEKARANG dirakit dari beberapa sumber (lihat
 * accounts.resolveApiLimit()):
 *   base       = daily_limit_api custom akun, ATAU globalPublicApiLimit
 *                (diatur admin lewat /setpublik), ATAU default config.json.
 *   senderBonus = bonus_active_senders -- naik +1 tiap sender milik akun
 *                ini berhasil konek, turun -2 tiap kali sender itu putus.
 *   redeemedBonus = redeemed_limit_api -- dari kode redeem (/crd di
 *                Telegram) dan/atau bonus broadcast admin (/al).
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, "rzone-db.json");
const TMP_FILE = DB_FILE + ".tmp";

function defaultState() {
  return {
    nextUserId: 1,
    users: [], // { id, email, google_sub, api_key, daily_limit_web, daily_limit_api, bonus_active_senders, redeemed_limit_api, created_at }
    dailyUsage: {}, // "<userId>:<kind>:<period>" -> count
    nextLogId: 1,
    usageLog: [], // { id, user_id, kind, link, at } -- terbaru di akhir array
    senders: [], // { id, label, ownerId, createdAt } -- registry sender WA publik (lihat senderPool.js)
    globalPublicApiLimit: null, // diatur admin lewat /setpublik di Telegram
    redeemCodes: [], // { code, limitAmount, usageQuota, usedCount, redeemedBy: [], createdAt }
    systemStatus: {
      // Dua flag INDEPENDEN, diatur admin lewat Telegram (lihat systemStatus.js):
      //   closed      -> /close & /open   (web "ditutup", tunggu pengumuman)
      //   maintenance -> /m & /sm         (web "maintenance", perbaikan sedang berjalan)
      // Kalau salah satu true -> web/API/controller reactch semuanya diblokir.
      closed: false,
      maintenance: false,
      closedAt: null,
      maintenanceAt: null,
    },
  };
}

function saveState(s) {
  fs.writeFileSync(TMP_FILE, JSON.stringify(s), "utf8");
  fs.renameSync(TMP_FILE, DB_FILE); // rename = atomik di level filesystem
}

function loadState() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    // Migrasi lembut: pastikan field baru selalu ada walau file lama
    // dibuat sebelum fitur-fitur ini ditambahkan.
    if (!Array.isArray(parsed.senders)) parsed.senders = [];
    parsed.senders = parsed.senders.map((s) => ({ ownerId: null, ...s }));
    if (typeof parsed.globalPublicApiLimit !== "number") parsed.globalPublicApiLimit = null;
    if (!Array.isArray(parsed.redeemCodes)) parsed.redeemCodes = [];
    if (!parsed.systemStatus || typeof parsed.systemStatus !== "object") {
      parsed.systemStatus = { closed: false, maintenance: false, closedAt: null, maintenanceAt: null };
    }
    parsed.users = (parsed.users || []).map((u) => ({
      bonus_active_senders: 0,
      redeemed_limit_api: 0,
      ...u,
    }));
    return parsed;
  } catch {
    const fresh = defaultState();
    saveState(fresh);
    return fresh;
  }
}

const state = loadState();

function persist() {
  saveState(state);
}

// ===================== Users (identitas = email Google) =====================

function findUserByEmail(email) {
  return state.users.find((u) => u.email === email) || null;
}
function findUserByApiKey(apiKey) {
  if (!apiKey) return null;
  return state.users.find((u) => u.api_key === apiKey) || null;
}
function findUserById(id) {
  return state.users.find((u) => u.id === id) || null;
}
function createUser(email, googleSub, apiKey) {
  const user = {
    id: state.nextUserId++,
    email,
    google_sub: googleSub,
    api_key: apiKey,
    daily_limit_web: null,
    daily_limit_api: null,
    bonus_active_senders: 0,
    redeemed_limit_api: 0,
    created_at: new Date().toISOString(),
  };
  state.users.push(user);
  persist();
  return user;
}
function updateUserApiKey(id, newKey) {
  const user = findUserById(id);
  if (!user) return;
  user.api_key = newKey;
  persist();
}
function setUserLimit(email, kind, value) {
  const user = findUserByEmail(email);
  if (!user) return null;
  user[kind === "web" ? "daily_limit_web" : "daily_limit_api"] = value;
  persist();
  return user;
}
function clearUserLimit(email, kind) {
  return setUserLimit(email, kind, null);
}
function allUsers() {
  return state.users.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
}

/**
 * Naik/turunkan bonus limit API dari status sender (+1 tiap konek, -2 tiap
 * putus -- lihat senderPool.js). Tidak pernah boleh negatif.
 */
function adjustSenderBonus(userId, delta) {
  const user = findUserById(userId);
  if (!user) return;
  const current = user.bonus_active_senders || 0;
  user.bonus_active_senders = Math.max(0, current + delta);
  persist();
}

/**
 * Tambahkan bonus PERMANEN (dari redeem code / broadcast admin) ke 1 akun.
 */
function addRedeemedBonus(userId, amount) {
  const user = findUserById(userId);
  if (!user) return;
  user.redeemed_limit_api = (user.redeemed_limit_api || 0) + amount;
  persist();
}

/**
 * Broadcast: tambahkan `amount` ke redeemed_limit_api SEMUA akun yang ada
 * SAAT INI (dipakai command /al di Telegram). Mengembalikan jumlah akun
 * yang kena.
 */
function addBonusToAllUsers(amount) {
  state.users.forEach((u) => {
    u.redeemed_limit_api = (u.redeemed_limit_api || 0) + amount;
  });
  persist();
  return state.users.length;
}

function setGlobalPublicApiLimit(amount) {
  state.globalPublicApiLimit = amount;
  persist();
}
function getGlobalPublicApiLimit() {
  return typeof state.globalPublicApiLimit === "number" ? state.globalPublicApiLimit : null;
}

// ===================== Kuota harian =====================

function usageKey(userId, kind, period) {
  return `${userId}:${kind}:${period}`;
}
function getUsageCount(userId, kind, period) {
  return state.dailyUsage[usageKey(userId, kind, period)] || 0;
}
function incrementUsage(userId, kind, period) {
  const key = usageKey(userId, kind, period);
  state.dailyUsage[key] = (state.dailyUsage[key] || 0) + 1;
  persist();
  return state.dailyUsage[key];
}

// ===================== Log riwayat =====================

function addLog(userId, kind, link) {
  state.usageLog.push({
    id: state.nextLogId++,
    user_id: userId,
    kind,
    link,
    at: new Date().toISOString(),
  });
  persist();
}
function recentLogs(userId, kind, limit) {
  return state.usageLog
    .filter((l) => l.user_id === userId && (kind ? l.kind === kind : true))
    .slice(-limit)
    .reverse();
}
function countLogs(userId) {
  return state.usageLog.filter((l) => l.user_id === userId).length;
}

// WIB (UTC+7) dipakai konsisten dengan accounts.periodKey() -- supaya
// "hari ini" di Telegram sama persis dengan reset kuota jam 00:01 WIB.
const DB_WIB_OFFSET_MS = 7 * 60 * 60 * 1000;
function logPeriodKey(isoAt) {
  return new Date(new Date(isoAt).getTime() + DB_WIB_OFFSET_MS).toISOString().slice(0, 10);
}

/** Total react (jumlah link diproses, semua user & kind) pada 1 tanggal WIB. */
function countLogsInPeriod(period) {
  return state.usageLog.filter((l) => logPeriodKey(l.at) === period).length;
}

/** Ranking user berdasar jumlah react pada 1 tanggal WIB, terbanyak dulu. */
function leaderboardInPeriod(period, limit = 10) {
  const counts = new Map();
  for (const l of state.usageLog) {
    if (logPeriodKey(l.at) !== period) continue;
    counts.set(l.user_id, (counts.get(l.user_id) || 0) + 1);
  }
  return Array.from(counts.entries())
    .map(([userId, count]) => {
      const user = findUserById(userId);
      return { email: user?.email || `user#${userId}`, count };
    })
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

// ===================== Status sistem: /close /open /m /sm (Telegram) =====================

function getSystemStatus() {
  return { ...state.systemStatus };
}
function setClosed(value) {
  state.systemStatus.closed = value;
  state.systemStatus.closedAt = value ? new Date().toISOString() : null;
  persist();
}
function setMaintenance(value) {
  state.systemStatus.maintenance = value;
  state.systemStatus.maintenanceAt = value ? new Date().toISOString() : null;
  persist();
}

// ===================== Registry sender WhatsApp publik =====================
// Cuma menyimpan DAFTAR id sender yang pernah dipasang (supaya server bisa
// menyambungkan ulang semua sender begitu restart). Kredensial WhatsApp
// sesungguhnya disimpan terpisah oleh Baileys sendiri di folder
// `auth_info_senders/<id>/` (lihat senderPool.js) -- BUKAN di sini.

function addSenderRecord(id, label, ownerId) {
  if (state.senders.some((s) => s.id === id)) return;
  state.senders.push({
    id,
    label: label || id,
    ownerId: ownerId ?? null,
    createdAt: new Date().toISOString(),
  });
  persist();
}
function removeSenderRecord(id) {
  state.senders = state.senders.filter((s) => s.id !== id);
  persist();
}
function listSenderRecords() {
  return state.senders.slice();
}

// ===================== Kode Redeem (dibuat lewat Telegram: /crd) =====================

function createRedeemCode(code, limitAmount, usageQuota) {
  if (state.redeemCodes.some((c) => c.code === code)) {
    throw new Error("Kode ini sudah pernah dibuat.");
  }
  state.redeemCodes.push({
    code,
    limitAmount,
    usageQuota,
    usedCount: 0,
    redeemedBy: [],
    createdAt: new Date().toISOString(),
  });
  persist();
}
function findRedeemCode(code) {
  return state.redeemCodes.find((c) => c.code === code) || null;
}
function listRedeemCodes() {
  return state.redeemCodes.slice();
}

/**
 * Tukar 1 kode redeem untuk 1 akun. Atomik (synchronous, tanpa `await` di
 * tengah) -- tidak mungkin 1 akun "kebetulan" berhasil redeem 2x kode yang
 * sama lewat request paralel, dan tidak mungkin kode kepakai melebihi
 * kuotanya sendiri.
 */
function redeemCode(code, userId) {
  const entry = findRedeemCode(code);
  if (!entry) {
    const err = new Error("Kode redeem tidak ditemukan.");
    err.code = "REDEEM_NOT_FOUND";
    throw err;
  }
  if (entry.usedCount >= entry.usageQuota) {
    const err = new Error("Kode redeem ini sudah habis kuotanya.");
    err.code = "REDEEM_EXHAUSTED";
    throw err;
  }
  if (entry.redeemedBy.includes(userId)) {
    const err = new Error("Kamu sudah pernah memakai kode ini sebelumnya.");
    err.code = "REDEEM_ALREADY_USED";
    throw err;
  }

  entry.usedCount += 1;
  entry.redeemedBy.push(userId);
  const user = findUserById(userId);
  if (user) {
    user.redeemed_limit_api = (user.redeemed_limit_api || 0) + entry.limitAmount;
  }
  persist();

  return { limitAmount: entry.limitAmount, remainingQuota: entry.usageQuota - entry.usedCount };
}

function generateRandomToken() {
  return crypto.randomBytes(24).toString("hex");
}

module.exports = {
  findUserByEmail,
  findUserByApiKey,
  findUserById,
  createUser,
  updateUserApiKey,
  setUserLimit,
  clearUserLimit,
  allUsers,
  adjustSenderBonus,
  addRedeemedBonus,
  addBonusToAllUsers,
  setGlobalPublicApiLimit,
  getGlobalPublicApiLimit,
  getUsageCount,
  incrementUsage,
  addLog,
  recentLogs,
  countLogs,
  countLogsInPeriod,
  leaderboardInPeriod,
  getSystemStatus,
  setClosed,
  setMaintenance,
  addSenderRecord,
  removeSenderRecord,
  listSenderRecords,
  createRedeemCode,
  findRedeemCode,
  listRedeemCodes,
  redeemCode,
  generateRandomToken,
};
