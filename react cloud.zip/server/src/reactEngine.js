/**
 * Logika eksekusi "react" yang SAMA dipakai oleh /api/react (web) dan
 * /api/dev/react (API developer) -- supaya perilakunya konsisten.
 *
 * Model baru:
 *   - SETIAP sender publik yang sedang aktif memilih SATU emoji secara
 *     ACAK dari daftar emoji yang diminta, lalu mereaksi pesan targetnya
 *     masing-masing. Jumlah reaksi yang muncul di pesan target = jumlah
 *     sender aktif saat itu.
 *   - Kalau controller (botrc) menyala DAN sedang tersambung, controller
 *     ikut menambahkan reaksinya sendiri (mekanisme lama: command
 *     `.reactch`, reaksi berurutan untuk SEMUA emoji yang diminta) --
 *     ini di LUAR/tambahan dari reaksi para sender publik.
 *
 * Aturan wajib-tidaknya sender aktif TERGANTUNG `botrc`:
 *   - botrc = true  -> request TETAP BOLEH diproses walau sender aktif 0
 *     (controller bisa jalan sendirian tanpa bantuan sender publik).
 *   - botrc = false -> minimal HARUS ada 1 sender aktif, kalau tidak
 *     request DITOLAK (tidak diproses sama sekali).
 */

const senderPool = require("./senderPool");
const senderReactQueue = require("./senderReactQueue");
const reactQueue = require("./reactQueue");
const controllerBot = require("./controllerBot");
const systemStatus = require("./systemStatus");

class NoActiveSenderError extends Error {
  constructor() {
    super("Tidak ada sender WhatsApp yang aktif saat ini. Request tidak bisa diproses.");
    this.code = "NO_ACTIVE_SENDER";
  }
}

class SystemBlockedError extends Error {
  constructor() {
    super(systemStatus.blockedMessage() || "Sedang tidak bisa memproses react.");
    this.code = "SYSTEM_BLOCKED";
  }
}

async function executeReact({ link, emojis, targetGroupIds }) {
  // Jaring pengaman kedua (selain middleware di routes/react.js &
  // routes/dev.js) -- kalau web closed atau maintenance, TIDAK ADA reaksi
  // yang boleh terkirim lewat jalur mana pun.
  if (systemStatus.isBlocked()) {
    throw new SystemBlockedError();
  }

  const activeSenders = senderPool.getActiveSenders();
  const controllerEnabled = controllerBot.isEnabled();

  // Sender aktif WAJIB ada HANYA kalau controller (botrc) sedang mati.
  // Kalau botrc=true, controller dianggap sanggup jalan sendirian.
  if (activeSenders.length === 0 && !controllerEnabled) {
    throw new NoActiveSenderError();
  }

  // Semua sender "mendaftarkan" slot antriannya secara sinkron di sini
  // (lihat globalQueue.js) -- baru kemudian masing-masing menunggu
  // giliran & benar-benar mengirim reaksinya.
  const senderResults = await Promise.all(
    activeSenders.map((sender) =>
      senderReactQueue.enqueue(() => senderPool.reactWithSender(sender, link, emojis))
    )
  );

  let controllerResult = null;
  if (controllerEnabled && controllerBot.getStatus().connected) {
    try {
      const result = await reactQueue.enqueue(() =>
        controllerBot.sendReactchCommand({ link, emojis, targetGroupIds })
      );
      controllerResult = { ok: true, ...result };
    } catch (err) {
      controllerResult = { ok: false, error: err.message };
    }
  }

  const successCount = senderResults.filter((r) => r.ok).length;

  return {
    activeSenderCount: activeSenders.length,
    successCount,
    senderResults,
    controllerUsed: controllerResult !== null,
    controllerResult,
  };
}

module.exports = { executeReact, NoActiveSenderError, SystemBlockedError };
