const express = require("express");
const router = express.Router();
const accounts = require("../accounts");
const session = require("../session");
const senderPool = require("../senderPool");
const reactEngine = require("../reactEngine");
const systemStatus = require("../systemStatus");
const config = require("../../config.json");

const DAILY_LIMIT_API = config.developerMode?.dailyLimitPerApiKey ?? 10;

// Sama seperti routes/react.js -- selama closed/maintenance, SELURUH
// endpoint /api/dev/* diblokir (bukan cuma /react), supaya konsisten
// dengan "api juga gak bisa" selagi web ditutup/maintenance.
router.use((req, res, next) => {
  if (systemStatus.isBlocked()) {
    return res.status(503).json({
      error: systemStatus.blockedMessage(),
      closed: systemStatus.isClosed(),
      maintenance: systemStatus.isMaintenance(),
    });
  }
  next();
});

// Middleware validasi API key -- login (Google) tetap dibutuhkan HANYA
// untuk melihat/mengganti API key sendiri di /me & /regenerate, bukan
// untuk endpoint /react (yang memang dipanggil server-to-server).
function requireApiKey(req, res, next) {
  const apiKey = req.header("x-api-key");
  if (!apiKey) return res.status(401).json({ error: "Header x-api-key wajib diisi." });

  const user = accounts.findByApiKey(apiKey);
  if (!user) return res.status(401).json({ error: "API key tidak valid." });

  try {
    const limit = accounts.resolveLimit(user, "api", DAILY_LIMIT_API);
    const usage = accounts.checkAndConsume(user.id, "api", limit);
    req.apiUser = user;
    res.setHeader("X-RateLimit-Remaining", usage.remaining);
    next();
  } catch (err) {
    res.status(429).json({ error: err.message });
  }
}

// POST /api/dev/react -> sama seperti /api/react tapi pakai API key + limit harian sendiri
router.post("/react", requireApiKey, async (req, res) => {
  try {
    const { link, emojis, targetGroupIds } = req.body || {};
    if (!link || !Array.isArray(emojis) || emojis.length === 0) {
      return res.status(400).json({ error: "Field 'link' dan 'emojis' wajib diisi." });
    }

    accounts.recordLog(req.apiUser.id, "api", link);
    const result = await reactEngine.executeReact({ link, emojis, targetGroupIds });

    res.json({ ok: true, success: result.successCount > 0, result });
  } catch (err) {
    if (err.code === "NO_ACTIVE_SENDER" || err.code === "SYSTEM_BLOCKED") {
      return res.status(503).json({ error: err.message });
    }
    res.status(400).json({ error: "Gagal memproses permintaan." });
  }
});

// GET /api/dev/me -> lihat API key sendiri (WAJIB sudah login lewat Google)
router.get("/me", session.requireAuth, (req, res) => {
  const limit = accounts.resolveLimit(req.user, "api", DAILY_LIMIT_API);
  const usage = accounts.getUsage(req.user.id, "api", limit);
  const breakdown = accounts.getApiLimitBreakdown(req.user, DAILY_LIMIT_API);
  res.json({ ok: true, email: req.user.email, apiKey: req.user.api_key, quota: usage, limitBreakdown: breakdown });
});

// POST /api/dev/redeem -> tukar kode redeem (dibuat admin lewat /crd di
// Telegram) untuk dapat tambahan limit API PERMANEN.
router.post("/redeem", session.requireAuth, (req, res) => {
  const { code } = req.body || {};
  if (!code || typeof code !== "string") {
    return res.status(400).json({ error: "Field 'code' wajib diisi." });
  }
  try {
    const result = accounts.redeemCode(code.trim(), req.user.id);
    const limit = accounts.resolveLimit(req.user, "api", DAILY_LIMIT_API);
    res.json({ ok: true, addedLimit: result.limitAmount, newLimit: limit });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/dev/regenerate -> ganti API key akun yang sedang login.
router.post("/regenerate", session.requireAuth, (req, res) => {
  const newKey = accounts.regenerateApiKey(req.user.id);
  res.json({ ok: true, apiKey: newKey });
});

// GET /api/dev/stats -> dashboard: sisa kuota API + riwayat link+jam
router.get("/stats", session.requireAuth, (req, res) => {
  const limit = accounts.resolveLimit(req.user, "api", DAILY_LIMIT_API);
  const usage = accounts.getUsage(req.user.id, "api", limit);
  const breakdown = accounts.getApiLimitBreakdown(req.user, DAILY_LIMIT_API);
  const history = accounts.getRecentLog(req.user.id, "api", 50);
  const detail = accounts.findAccountDetail(req.user.email, DAILY_LIMIT_API);
  res.json({
    ok: true,
    email: req.user.email,
    quota: usage,
    limitBreakdown: breakdown,
    stats: { totalRequests: detail?.totalRequests ?? 0 },
    history,
  });
});

module.exports = router;
