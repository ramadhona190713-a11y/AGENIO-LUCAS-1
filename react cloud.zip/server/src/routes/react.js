const express = require("express");
const router = express.Router();
const accounts = require("../accounts");
const session = require("../session");
const senderPool = require("../senderPool");
const controllerBot = require("../controllerBot");
const reactEngine = require("../reactEngine");
const systemStatus = require("../systemStatus");
const config = require("../../config.json");

const DAILY_LIMIT_WEB = config.reactMode?.dailyLimitPerIp ?? 2;

// Selama web "closed" (/close di Telegram) atau "maintenance" (/m), SELURUH
// endpoint di file ini diblokir -- dicek PALING DEPAN, sebelum requireAuth,
// supaya pesannya jelas ("sedang ditutup/maintenance") bukan malah minta
// login dulu.
router.use((req, res, next) => {
  if (systemStatus.isBlocked()) {
    return res.status(503).json({
      error: systemStatus.blockedMessage(),
      closed: systemStatus.isClosed(),
      maintenance: systemStatus.isMaintenance(),
    });
  }
  next();
});

// WAJIB LOGIN (Google) untuk semua endpoint di file ini.
router.use(session.requireAuth);

// GET /api/react/status -> kuota tersisa hari ini + jumlah sender aktif,
// TANPA memakai kuota.
router.get("/status", (req, res) => {
  const limit = accounts.resolveLimit(req.user, "web", DAILY_LIMIT_WEB);
  const usage = accounts.getUsage(req.user.id, "web", limit);
  res.json({ ...usage, activeSenderCount: senderPool.getActiveCount() });
});

// POST /api/react
// body: { link: string, emojis: string[], targetGroupIds?: string[] }
router.post("/", async (req, res) => {
  try {
    const { link, emojis, targetGroupIds } = req.body || {};

    if (!link || typeof link !== "string") {
      return res.status(400).json({ error: "Field 'link' wajib diisi." });
    }
    if (!Array.isArray(emojis) || emojis.length === 0) {
      return res
        .status(400)
        .json({ error: "Field 'emojis' wajib diisi, contoh: ['🔥','❤️']" });
    }

    // Sender aktif WAJIB ada HANYA kalau controller (botrc) sedang mati --
    // kalau botrc=true, controller dianggap sanggup jalan sendirian tanpa
    // sender publik. Cek ini dilakukan SEBELUM memakai kuota, supaya kalau
    // request ditolak, kuota user tidak ikut terpotong sia-sia.
    if (senderPool.getActiveCount() === 0 && !controllerBot.isEnabled()) {
      return res.status(503).json({
        error: "Tidak ada sender WhatsApp yang aktif saat ini. Coba lagi nanti.",
      });
    }

    const limit = accounts.resolveLimit(req.user, "web", DAILY_LIMIT_WEB);
    const usage = accounts.checkAndConsume(req.user.id, "web", limit);
    accounts.recordLog(req.user.id, "web", link);

    const result = await reactEngine.executeReact({ link, emojis, targetGroupIds });

    res.json({ ok: true, success: result.successCount > 0, quota: usage, result });
  } catch (err) {
    if (err.code === "LIMIT_REACHED") {
      return res.status(429).json({ error: err.message });
    }
    if (err.code === "NO_ACTIVE_SENDER" || err.code === "SYSTEM_BLOCKED") {
      return res.status(503).json({ error: err.message });
    }
    res.status(400).json({ error: "Gagal memproses permintaan." });
  }
});

module.exports = router;
