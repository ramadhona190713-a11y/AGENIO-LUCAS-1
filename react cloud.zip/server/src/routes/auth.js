const express = require("express");
const router = express.Router();
const googleAuth = require("../googleAuth");
const accounts = require("../accounts");
const session = require("../session");

// GET /api/auth/google/start -> redirect ke halaman consent Google.
// Ini yang diklik dari tombol "Login dengan Google" di web (link biasa,
// BUKAN fetch -- harus full-page redirect karena Google tidak mengizinkan
// consent screen dibuka di dalam iframe/fetch).
router.get("/google/start", (req, res) => {
  if (!googleAuth.isConfigured()) {
    return res
      .status(500)
      .send(
        "Login Google belum dikonfigurasi di server. Operator perlu mengisi " +
          "config.json -> googleClientId & googleClientSecret terlebih dahulu."
      );
  }
  res.redirect(googleAuth.buildAuthUrl());
});

// GET /api/auth/google/callback?code=...&state=... -> Google redirect ke sini
// setelah user setuju di consent screen.
router.get("/google/callback", async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.status(400).send(`Login Google dibatalkan/gagal: ${error}`);
  }
  if (!code || !googleAuth.consumeState(state)) {
    return res
      .status(400)
      .send("Proses login tidak valid atau sudah kedaluwarsa. Silakan ulangi dari halaman web.");
  }

  try {
    const profile = await googleAuth.exchangeCodeForProfile(String(code));
    const user = accounts.findOrCreateByEmail(profile.email, profile.sub);
    session.issueSession(res, user.id);
    res.redirect("/?login=success");
  } catch (err) {
    res.status(400).send(`Gagal login dengan Google: ${err.message}`);
  }
});

router.post("/logout", (req, res) => {
  session.clearSession(res);
  res.json({ ok: true });
});

// GET /api/auth/me -> siapa yang sedang login (dipakai frontend untuk cek status)
router.get("/me", (req, res) => {
  const user = session.getSessionUser(req);
  if (!user) return res.status(401).json({ ok: false });
  res.json({ ok: true, email: user.email, apiKey: user.api_key });
});

module.exports = router;
