/**
 * Bot Telegram khusus ADMIN untuk mengatur akun developer tanpa perlu buka
 * SFTP/File Manager tiap kali mau lihat/ubah limit harian per API key.
 *
 * KEAMANAN:
 * - Hanya merespons chat ID yang ada di config.telegramBot.adminChatIds.
 *   Pesan dari chat ID lain DIABAIKAN TOTAL (tidak ada balasan apa pun) —
 *   supaya orang asing yang menemukan bot ini bahkan tidak tahu ada
 *   perintah apa saja yang tersedia (mengurangi permukaan serangan).
 * - API key TIDAK PERNAH dikirim utuh lewat Telegram, selalu di-mask
 *   (lihat accounts.maskApiKey), supaya walau akun Telegram admin kena
 *   retas/chat ter-forward, key asli tidak ikut bocor.
 * - Bot token TIDAK PERNAH di-log ke console (bahkan sebagian).
 * - Semua input (nomor WA, angka limit) divalidasi lewat fungsi yang sama
 *   dipakai HTTP routes (accounts.js) — jadi aturan bisnisnya konsisten,
 *   tidak ada jalur pintas yang melewati validasi.
 * - Nonaktif secara default (config.telegramBot.enabled=false) supaya
 *   deployment yang belum sempat isi token tidak ikut mencoba konek dan
 *   memenuhi log dengan error.
 *
 * Dipakai lewat long-polling (getUpdates) pakai fetch bawaan Node.js —
 * SENGAJA tidak menambah dependency npm baru untuk fitur ini.
 */

const accounts = require("./accounts");
const senderPool = require("./senderPool");
const controllerBot = require("./controllerBot");
const systemStatus = require("./systemStatus");

const API_BASE = "https://api.telegram.org/bot";
const POLL_TIMEOUT_SEC = 30;

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatAccountLine(acc) {
  const limitLabel = acc.isCustomLimit ? `${acc.dailyLimit} (custom)` : `${acc.dailyLimit} (default)`;
  return (
    `• <b>${escapeHtml(acc.email)}</b>\n` +
    `  key: <code>${escapeHtml(acc.apiKeyMasked)}</code>\n` +
    `  limit: ${limitLabel} | hari ini: ${acc.usedToday}/${acc.dailyLimit} | total: ${acc.totalRequests}`
  );
}

// Telegram batasi ~4096 karakter per pesan -> pecah jadi beberapa pesan
// kalau daftar akunnya panjang.
function chunkMessage(lines, sep = "\n\n", maxLen = 3500) {
  const chunks = [];
  let current = "";
  for (const line of lines) {
    const candidate = current ? current + sep + line : line;
    if (candidate.length > maxLen && current) {
      chunks.push(current);
      current = line;
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

function createTelegramBot(config) {
  const cfg = config?.telegramBot;
  if (!cfg || !cfg.enabled) {
    console.log("[TelegramBot] Nonaktif (telegramBot.enabled=false di config.json).");
    return { start() {}, stop() {} };
  }
  if (!cfg.botToken || typeof cfg.botToken !== "string" || cfg.botToken.length < 20) {
    console.log("[TelegramBot] Nonaktif: telegramBot.botToken belum diisi di config.json.");
    return { start() {}, stop() {} };
  }
  const adminChatIds = new Set((cfg.adminChatIds || []).map((id) => String(id)));
  if (adminChatIds.size === 0) {
    console.log("[TelegramBot] Nonaktif: telegramBot.adminChatIds masih kosong di config.json.");
    return { start() {}, stop() {} };
  }

  const apiUrl = `${API_BASE}${cfg.botToken}`;
  const defaultDailyLimit = config.developerMode?.dailyLimitPerApiKey ?? 10;

  let running = false;
  let offset = 0;

  async function callApi(method, body) {
    const res = await fetch(`${apiUrl}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return res.json();
  }

  async function sendMessage(chatId, text) {
    try {
      await callApi("sendMessage", {
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
      });
    } catch (err) {
      console.error("[TelegramBot] Gagal kirim pesan:", err.message);
    }
  }

  const HELP_TEXT =
    "<b>Rzone WA Bot — Admin Panel</b>\n\n" +
    "/accounts — daftar semua akun developer & limit hariannya\n" +
    "/account &lt;email&gt; — detail 1 akun + 5 link terakhir\n" +
    "/setlimit &lt;email&gt; &lt;angka&gt; — set limit harian custom akun\n" +
    "/resetlimit &lt;email&gt; — kembalikan ke limit default\n" +
    "/senders — jumlah & daftar sender WhatsApp publik yang aktif\n" +
    "/crd &lt;kode&gt; &lt;limit_didapat&gt; &lt;jumlah_kuota&gt; — buat kode redeem baru\n" +
    "/al &lt;jumlah&gt; — beri bonus limit API ke SEMUA akun sekaligus\n" +
    "/setpublik &lt;jumlah&gt; — ubah limit API dasar publik (semua akun tanpa custom limit)\n\n" +
    "<b>Tutup / Maintenance</b>\n" +
    "/close — tutup web+API+controller sampai /open (pengumuman di channel WA)\n" +
    "/open — buka lagi setelah /close\n" +
    "/m — mode maintenance (web+API+controller berhenti sementara)\n" +
    "/sm — selesai maintenance, aktifkan lagi\n" +
    "/statuswebsite — cek status closed/maintenance saat ini\n\n" +
    "<b>Statistik</b>\n" +
    "/reacthariini — jumlah react hari ini (semua user)\n" +
    "/leaderboard — ranking user paling banyak react hari ini\n\n" +
    "/help — tampilkan pesan ini";

  async function handleCommand(chatId, text) {
    const parts = text.trim().split(/\s+/);
    const cmd = (parts[0] || "").toLowerCase().replace(/@.*$/, ""); // buang @botname kalau ada

    if (cmd === "/start" || cmd === "/help") {
      return sendMessage(chatId, HELP_TEXT);
    }

    if (cmd === "/accounts") {
      const accountList = accounts.listAccountsSummary(defaultDailyLimit);
      if (accountList.length === 0) {
        return sendMessage(chatId, "Belum ada akun developer yang terdaftar.");
      }
      const lines = accountList.map(formatAccountLine);
      const chunks = chunkMessage(lines);
      for (const chunk of chunks) {
        await sendMessage(chatId, chunk);
      }
      return;
    }

    if (cmd === "/account") {
      const email = parts[1];
      if (!email) return sendMessage(chatId, "Format: /account nama@gmail.com");
      const detail = accounts.findAccountDetail(email, defaultDailyLimit);
      if (!detail) return sendMessage(chatId, "Akun tidak ditemukan.");
      const limitLabel = detail.isCustomLimit
        ? `${detail.dailyLimit} (custom)`
        : `${detail.dailyLimit} (default)`;
      const linksText =
        detail.recentLinks.length > 0
          ? detail.recentLinks
              .map((l) => `  - ${escapeHtml(l.link)} (${new Date(l.at).toLocaleString("id-ID")})`)
              .join("\n")
          : "  (belum ada)";
      return sendMessage(
        chatId,
        `<b>${escapeHtml(detail.email)}</b>\n` +
          `key: <code>${escapeHtml(detail.apiKeyMasked)}</code>\n` +
          `limit: ${limitLabel}\n` +
          `hari ini: ${detail.usedToday}/${detail.dailyLimit}\n` +
          `total request: ${detail.totalRequests}\n\n` +
          `5 link terakhir:\n${linksText}`
      );
    }

    if (cmd === "/setlimit") {
      const email = parts[1];
      const num = Number(parts[2]);
      if (!email || !parts[2]) {
        return sendMessage(chatId, "Format: /setlimit nama@gmail.com 50");
      }
      try {
        const result = accounts.setDailyLimitByEmail(email, num);
        return sendMessage(
          chatId,
          `✅ Limit harian <b>${escapeHtml(result.email)}</b> diubah jadi <b>${result.dailyLimit}</b>/hari.`
        );
      } catch (err) {
        return sendMessage(chatId, `⚠️ ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/resetlimit") {
      const email = parts[1];
      if (!email) return sendMessage(chatId, "Format: /resetlimit nama@gmail.com");
      try {
        const result = accounts.clearDailyLimitByEmail(email);
        return sendMessage(
          chatId,
          `✅ Limit harian <b>${escapeHtml(result.email)}</b> dikembalikan ke default (${defaultDailyLimit}/hari).`
        );
      } catch (err) {
        return sendMessage(chatId, `⚠️ ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/senders") {
      const list = senderPool.listSenders();
      const active = list.filter((s) => s.status === "connected");
      if (list.length === 0) {
        return sendMessage(chatId, "Belum ada sender publik yang pernah ditambahkan.");
      }
      const lines = list.map(
        (s) =>
          `• ${escapeHtml(s.phoneNumber || s.id)} — ${s.status === "connected" ? "🟢 aktif" : "🔴 " + escapeHtml(s.status)}`
      );
      return sendMessage(
        chatId,
        `<b>Jumlah sender aktif: ${active.length}/${list.length}</b>\n\n${lines.join("\n")}`
      );
    }

    if (cmd === "/crd") {
      const code = parts[1];
      const limitAmount = Number(parts[2]);
      const usageQuota = Number(parts[3]);
      if (!code || !parts[2] || !parts[3]) {
        return sendMessage(
          chatId,
          "Format: /crd &lt;kode&gt; &lt;limit_didapat&gt; &lt;jumlah_kuota&gt;\nContoh: /crd LEBARAN2026 5 100"
        );
      }
      try {
        const result = accounts.createRedeemCode(code, limitAmount, usageQuota);
        return sendMessage(
          chatId,
          `✅ Kode redeem <b>${escapeHtml(result.code)}</b> dibuat.\n` +
            `Tiap yang redeem dapat +${result.limitAmount} limit API/hari, kode bisa dipakai total ${result.usageQuota}x (maks 1x per akun).`
        );
      } catch (err) {
        return sendMessage(chatId, `⚠️ ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/al") {
      const amount = Number(parts[1]);
      if (!parts[1]) return sendMessage(chatId, "Format: /al &lt;jumlah&gt;\nContoh: /al 3");
      try {
        const result = accounts.broadcastBonusToAll(amount);
        return sendMessage(
          chatId,
          `✅ +${result.amount} limit API/hari diberikan ke SEMUA akun (${result.affectedCount} akun terkena).`
        );
      } catch (err) {
        return sendMessage(chatId, `⚠️ ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/setpublik") {
      const amount = Number(parts[1]);
      if (!parts[1]) return sendMessage(chatId, "Format: /setpublik &lt;jumlah&gt;\nContoh: /setpublik 15");
      try {
        const result = accounts.setGlobalPublicLimit(amount);
        return sendMessage(
          chatId,
          `✅ Limit API dasar publik diubah jadi <b>${result.amount}</b>/hari untuk semua akun yang tidak punya limit custom.`
        );
      } catch (err) {
        return sendMessage(chatId, `⚠️ ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/close") {
      systemStatus.setClosed(true);
      return sendMessage(
        chatId,
        "🔒 Web DITUTUP.\n\n" +
          "Web akan langsung menampilkan halaman \"ditutup\", dan API (web+developer) " +
          "serta bot controller SEMUANYA berhenti (controller tetap tersambung, cuma " +
          "berhenti memproses, bukan disconnect) sampai /open dipanggil.\n\n" +
          "Info waktu & lanjutan akan disampaikan di:\n" +
          systemStatus.WHATSAPP_CHANNEL_URL
      );
    }

    if (cmd === "/open") {
      systemStatus.setClosed(false);
      return sendMessage(chatId, "🔓 Web DIBUKA lagi. Web, API, dan controller sudah aktif normal.");
    }

    if (cmd === "/m") {
      systemStatus.setMaintenance(true);
      return sendMessage(
        chatId,
        "🛠️ Mode MAINTENANCE aktif.\n\n" +
          "Web menampilkan halaman maintenance, API (web+developer) dan bot controller " +
          "berhenti sementara (controller tetap tersambung, tidak disconnect) sampai /sm dipanggil."
      );
    }

    if (cmd === "/sm") {
      systemStatus.setMaintenance(false);
      return sendMessage(chatId, "✅ Maintenance SELESAI. Web, API, dan controller sudah aktif normal.");
    }

    if (cmd === "/statuswebsite") {
      const s = systemStatus.getStatus();
      const lines = [
        `Closed: ${s.closed ? "🔒 YA (sejak " + new Date(s.closedAt).toLocaleString("id-ID") + ")" : "TIDAK"}`,
        `Maintenance: ${s.maintenance ? "🛠️ YA (sejak " + new Date(s.maintenanceAt).toLocaleString("id-ID") + ")" : "TIDAK"}`,
        `Controller: ${controllerBot.isPaused() ? "⏸️ berhenti sementara" : "▶️ normal"}`,
      ];
      return sendMessage(chatId, `<b>Status Website</b>\n\n${lines.join("\n")}`);
    }

    if (cmd === "/reacthariini") {
      const total = accounts.getTodayReactCount();
      return sendMessage(chatId, `📊 Jumlah react <b>hari ini</b>: <b>${total}</b>`);
    }

    if (cmd === "/leaderboard") {
      const rows = accounts.getTodayLeaderboard(10);
      if (rows.length === 0) {
        return sendMessage(chatId, "Belum ada react hari ini.");
      }
      const medals = ["🥇", "🥈", "🥉"];
      const lines = rows.map(
        (r, i) => `${medals[i] || `${i + 1}.`} ${escapeHtml(r.email)} — ${r.count}x`
      );
      return sendMessage(chatId, `<b>🏆 Leaderboard React Hari Ini</b>\n\n${lines.join("\n")}`);
    }

    // Perintah tidak dikenal dari admin -> arahkan ke /help (bukan diam,
    // karena ini sudah dipastikan admin yang sah).
    return sendMessage(chatId, "Perintah tidak dikenal. Ketik /help untuk daftar perintah.");  }

  async function pollLoop() {
    while (running) {
      try {
        const data = await callApi("getUpdates", {
          timeout: POLL_TIMEOUT_SEC,
          offset,
          allowed_updates: ["message"],
        });
        if (data.ok && Array.isArray(data.result)) {
          for (const update of data.result) {
            offset = update.update_id + 1;
            const msg = update.message;
            if (!msg || !msg.text || !msg.chat) continue;
            const chatId = String(msg.chat.id);
            // Diamkan total kalau bukan admin -> tidak ada jejak/balasan
            // sama sekali ke chat yang tidak diotorisasi.
            if (!adminChatIds.has(chatId)) continue;
            if (!msg.text.startsWith("/")) continue;
            await handleCommand(chatId, msg.text);
          }
        }
      } catch (err) {
        console.error("[TelegramBot] Polling error:", err.message);
        await new Promise((r) => setTimeout(r, 5000)); // backoff sebelum retry
      }
    }
  }

  return {
    start() {
      if (running) return;
      running = true;
      console.log("[TelegramBot] Aktif, mendengarkan perintah admin...");
      // Ambil update_id terbaru dulu (tanpa diproses) supaya command lama
      // yang menumpuk sebelum server nyala tidak ikut dieksekusi.
      callApi("getUpdates", { timeout: 0 })
        .then((data) => {
          if (data.ok && Array.isArray(data.result) && data.result.length > 0) {
            offset = data.result[data.result.length - 1].update_id + 1;
          }
        })
        .catch(() => {})
        .finally(() => {
          pollLoop();
        });
    },
    stop() {
      running = false;
    },
  };
}

module.exports = { createTelegramBot };
