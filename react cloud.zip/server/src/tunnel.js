const { spawn } = require("child_process");
const config = require("../config.json");

let tunnelProcess = null;

/**
 * Cari lokasi binary cloudflared. Diutamakan dari package npm `cloudflared`
 * (auto-download binary saat `npm install`, cocok buat hosting seperti
 * Pterodactyl yang tidak punya akses apt/dpkg). Kalau package itu gagal
 * dimuat, fallback ke command `cloudflared` di PATH sistem (untuk yang
 * install manual di server sendiri/VPS).
 */
function resolveCloudflaredBin() {
  try {
    const cf = require("cloudflared");
    if (cf?.bin) return cf.bin;
  } catch (err) {
    // package belum ke-install / gagal dimuat, fallback ke bawah
  }
  return "cloudflared"; // fallback: cari di PATH sistem
}

/**
 * Menjalankan `cloudflared tunnel run --token <token>` sebagai child process,
 * memakai token dari config.json. Dipanggil otomatis saat server start
 * (lihat index.js) — jadi cukup `npm start` saja.
 */
async function startTunnel() {
  const token = config.cloudflaredTunnelToken;

  if (!token || token.trim() === "" || token.includes("TARUH_TOKEN")) {
    console.log(
      "[Rzone] cloudflaredTunnelToken belum diisi di config.json — tunnel TIDAK dijalankan otomatis. " +
        "Isi tokennya lalu restart server kalau mau tunnel auto-start."
    );
    return null;
  }

  const bin = resolveCloudflaredBin();

  // Kalau pakai package npm `cloudflared`, pastikan binary-nya sudah
  // ke-download. Beberapa versi package butuh install() eksplisit.
  try {
    const cf = require("cloudflared");
    if (cf?.install) await cf.install(bin);
  } catch (err) {
    // abaikan; kalau memang belum ke-install, spawn di bawah akan gagal
    // dengan pesan error yang jelas (ENOENT) dan ditangani di listener 'error'
  }

  console.log("[Rzone] Menjalankan cloudflared tunnel...");
  console.log(`[Rzone] Menggunakan binary: ${bin}`);

  tunnelProcess = spawn(bin, ["tunnel", "run", "--token", token], {
    stdio: "inherit", // biar log cloudflared ikut tampil di terminal/console yang sama
  });

  tunnelProcess.on("error", (err) => {
    console.error(
      "[Rzone] Gagal menjalankan cloudflared:",
      err.message,
      "\n[Rzone] Pastikan dependency 'cloudflared' ke-install (jalankan 'npm install' lagi di folder server)."
    );
  });

  tunnelProcess.on("exit", (code) => {
    console.log(`[Rzone] cloudflared tunnel berhenti (kode keluar: ${code}).`);
    tunnelProcess = null;
  });

  return tunnelProcess;
}

/**
 * Matikan tunnel dengan rapi kalau server dimatikan (Ctrl+C, dsb),
 * supaya tidak ada proses cloudflared "menggantung" di background.
 */
function stopTunnel() {
  if (tunnelProcess) {
    tunnelProcess.kill();
    tunnelProcess = null;
  }
}

module.exports = { startTunnel, stopTunnel };
