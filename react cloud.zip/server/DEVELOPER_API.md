# Dokumentasi API — Rzone WA Bot (Mode Developer)

Login sekarang **lewat Google** (bukan email/password, bukan WhatsApp).
Setiap akun Google yang berhasil login otomatis dapat **1 akun + 1 API
key**, dengan limit default **10 request/hari** (reset otomatis tiap
pergantian hari WIB). Setup Google OAuth ada di `README.md` bagian 5.

Base URL: `https://domain-tunnel-kamu.trycloudflare.com` (isi sesuai
`config.publicBaseUrl`).

---

## 1. Login & Ambil API Key (dilakukan di web, bukan API langsung)

1. Buka halaman `/developer` → klik **"Login dengan Google"**.
2. Pilih akun Google kamu di halaman consent Google.
3. Setelah berhasil, API key kamu langsung tampil di halaman `/developer`.

## 2. Buat Ulang (Regenerate) API Key

```
POST /api/dev/regenerate
Cookie: rzone_sess=... (otomatis terkirim browser kalau sudah login)
```

Response:
```json
{ "ok": true, "apiKey": "rzone_yyyy..." }
```

## 3. Statistik & Riwayat Pemakaian

```
GET /api/dev/stats
Cookie: rzone_sess=...
```

Response:
```json
{
  "ok": true,
  "email": "kamu@gmail.com",
  "quota": { "used": 3, "remaining": 7, "limit": 10 },
  "stats": { "totalRequests": 42 },
  "history": [
    { "link": "https://whatsapp.com/channel/xxxx/123", "at": "2026-09-06T02:10:00.000Z" }
  ]
}
```

---

## 4. Kirim Perintah React

```
POST /api/dev/react
Content-Type: application/json
x-api-key: rzone_xxxxxxxxxxxxxxxxxxxxxxxx

{
  "link": "https://whatsapp.com/channel/xxxxx/123",
  "emojis": ["🔥", "❤️", "😂"]
}
```

**Cara kerja reaksinya (PENTING, beda dari versi lama):**

- Sistem mengecek semua **sender WhatsApp publik yang sedang aktif**
  (dipasang lewat halaman `/pairing` → "Add Sender Public").
- **SETIAP sender aktif memilih SATU emoji secara ACAK** dari daftar
  `emojis` yang kamu kirim, lalu mereaksi pesan yang memuat `link` tsb di
  riwayat grup miliknya sendiri.
- Kalau ada 5 sender aktif, pesan target akan dapat **5 reaksi** (masing-
  masing acak dari daftar emoji), BUKAN 1 akun yang mereaksi berkali-kali.
- Kalau **tidak ada sender aktif sama sekali**, request DITOLAK dengan
  status 503 dan kuota API kamu **tidak ikut terpakai**.
- Kalau operator mengaktifkan `botrc: true` di `config.json`, ada REAKSI
  TAMBAHAN dari 1 akun "controller" (mekanisme lama, mereaksi berurutan
  untuk SEMUA emoji yang diminta) — ini otomatis dan di luar kendali kamu
  sebagai pemanggil API.

Response sukses:
```json
{
  "ok": true,
  "success": true,
  "result": {
    "activeSenderCount": 5,
    "successCount": 4,
    "senderResults": [
      { "id": "…", "ok": true, "emoji": "🔥" },
      { "id": "…", "ok": false, "reason": "Pesan dengan link ini belum ditemukan di riwayat sender." }
    ],
    "controllerUsed": false,
    "controllerResult": null
  }
}
```

`successCount` bisa lebih kecil dari `activeSenderCount` — itu normal,
artinya sebagian sender belum "melihat" pesan dengan link tsb di grup yang
mereka ikuti (sender itu memang harus jadi anggota grup/channel yang
bersangkutan untuk bisa mereaksi).

Kalau tidak ada sender aktif:
```json
{ "error": "Tidak ada sender WhatsApp yang aktif saat ini. Request tidak bisa diproses." }
```
(HTTP status 503)

Kalau limit harian habis:
```json
{ "error": "Limit 10x/hari untuk fitur ini sudah tercapai. Coba lagi setelah reset jam 00:01 WIB." }
```
(HTTP status 429)

Header response `X-RateLimit-Remaining` menunjukkan sisa kuota API harianmu.

---

## Catatan Teknis & Keamanan

- **Tidak ada lagi mode anonim.** Endpoint `/api/dev/react` butuh
  `x-api-key`; `/api/dev/me`, `/api/dev/regenerate`, `/api/dev/stats` butuh
  sesi login Google.
- Data akun & kuota disimpan di file JSON tersinkron disk
  (`server/src/data/rzone-db.json`) — semua operasi baca-tulis SYNCHRONOUS
  (atomik di level Node.js) dan ditulis lewat pola tulis-lalu-rename (anti
  korup kalau proses mati mendadak). Sengaja TANPA dependency database
  native supaya tidak gagal install di hosting terbatas.
- Reaksi WhatsApp hanya mengizinkan **1 reaksi aktif per akun per pesan**
  — makanya tiap sender cuma pilih 1 emoji, bukan semuanya.
- Sender/bot hanya bisa mereaksi pesan yang linknya **sudah pernah muncul**
  di riwayat chat grup yang mereka ikuti, tersimpan sementara di memori
  server (lihat `messageStore.js`) — bukan pencarian link ke seluruh
  internet, dan hilang kalau server di-restart.
- **Catatan jujur soal batas sistem:** limit harian per akun tidak bisa
  ditembus dari akun yang sama, tapi tidak ada sistem gratis-terbuka yang
  bisa menjamin 100% seseorang tidak membuat banyak akun Google berbeda.
