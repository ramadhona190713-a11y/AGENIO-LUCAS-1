/**
 * Sistem Koin — menggantikan sistem limit harian lama.
 *
 * 3 jenis koin:
 *   - GREEN  (Hijau)  : react via WEB. Restock otomatis 2 koin/hari jam
 *                        00:00 WIB. Kalau user pernah top up hijau,
 *                        setelah habis auto restock 4 koin/hari selamanya.
 *   - YELLOW (Kuning) : mulai dari 0, hanya bertambah lewat top up.
 *                        1 koin = 1 react. TANPA restock otomatis.
 *   - BLUE   (Biru)   : khusus API. Restock 10 koin/hari jam 00:00 WIB.
 *                        Kalau butuh lebih, wajib top up.
 *
 * Harga top up:
 *   - Hijau  : Rp500/koin, min beli 4  (auto restock 4x/hari setelah habis)
 *   - Biru   : Rp700/koin, min beli 5  (auto restock juga)
 *   - Kuning : Rp150/koin, min beli 10 (tanpa restock)
 *
 * Di halaman react WEB user bisa PILIH pakai koin Hijau ATAU Kuning.
 * API developer SELALU pakai koin Biru.
 */

const db = require("./db");

const WIB_OFFSET_MS = 7 * 60 * 60 * 1000; // UTC+7

const COIN_TYPES = {
  green: {
    label: "Hijau",
    price: 500,
    minBuy: 4,
    dailyRestock: 2,
    topUpRestock: 4,
    use: "web",
  },
  yellow: {
    label: "Kuning",
    price: 150,
    minBuy: 10,
    dailyRestock: 0,
    topUpRestock: 0,
    use: "web",
  },
  blue: {
    label: "Biru",
    price: 700,
    minBuy: 5,
    dailyRestock: 10,
    topUpRestock: 10,
    use: "api",
  },
};

function periodKey(date = new Date()) {
  return new Date(date.getTime() + WIB_OFFSET_MS).toISOString().slice(0, 10);
}

function defaultCoins() {
  const today = periodKey();
  return {
    green: { balance: COIN_TYPES.green.dailyRestock, hasToppedUp: false, lastRestockDate: today },
    yellow: { balance: 0 },
    blue: { balance: COIN_TYPES.blue.dailyRestock, hasToppedUp: false, lastRestockDate: today },
  };
}

/**
 * Pastikan struktur koin user lengkap (migrasi lembut dari akun lama).
 */
function getCoins(user) {
  if (!user.coins) {
    user.coins = defaultCoins();
    db.persistUser(user);
  }
  for (const type of ["green", "yellow", "blue"]) {
    if (!user.coins[type]) {
      user.coins[type] =
        type === "yellow"
          ? { balance: 0 }
          : { balance: 0, hasToppedUp: false, lastRestockDate: null };
    }
  }
  return user.coins;
}

/**
 * Proses restock harian: kalau tanggal WIB sudah berganti sejak
 * lastRestockDate, isi ulang saldo sampai MINIMAL jumlah restock yang
 * berlaku ("ngisi 2 coin setiap 00.00 WIB").
 * Saldo yang sudah lebih besar (mis. hasil top up berbayar) TIDAK dikurangi
 * -- sebelumnya saldo di-SET ulang sehingga koin hasil top up bisa hilang.
 */
function processDailyRestock(user) {
  const coins = getCoins(user);
  const today = periodKey();
  let changed = false;

  for (const type of ["green", "blue"]) {
    const coin = coins[type];
    const cfg = COIN_TYPES[type];
    const restockAmount = coin.hasToppedUp ? cfg.topUpRestock : cfg.dailyRestock;

    if (coin.lastRestockDate !== today) {
      if (restockAmount > 0 && (coin.balance || 0) < restockAmount) {
        coin.balance = restockAmount;
      }
      coin.lastRestockDate = today;
      changed = true;
    }
  }

  if (changed) db.persistUser(user);
  return coins;
}

/**
 * Cek saldo cukup untuk `amount` koin tipe tertentu.
 */
function canAfford(user, coinType, amount = 1) {
  const coins = processDailyRestock(user);
  return (coins[coinType]?.balance || 0) >= amount;
}

/**
 * Konsumsi koin (atomik — synchronous, tanpa await di tengah).
 * Return true kalau berhasil dipotong, false kalau saldo tidak cukup.
 */
function consumeCoin(user, coinType, amount = 1) {
  const coins = processDailyRestock(user);
  const coin = coins[coinType];
  if (!coin || coin.balance < amount) return false;
  coin.balance -= amount;
  db.persistUser(user);
  return true;
}

/**
 * Kembalikan koin yang sudah terpotong (mis. react gagal total).
 */
function refundCoin(user, coinType, amount = 1) {
  const coins = getCoins(user);
  if (!coins[coinType]) return;
  coins[coinType].balance = (coins[coinType].balance || 0) + amount;
  db.persistUser(user);
}

/**
 * Tambah koin dari top up (dipanggil setelah payment terverifikasi).
 */
function addCoins(userId, coinType, amount) {
  const user = db.findUserById(userId);
  if (!user) throw new Error("User tidak ditemukan.");
  const coins = getCoins(user);
  coins[coinType].balance = (coins[coinType].balance || 0) + amount;
  if (coinType === "green" || coinType === "blue") {
    coins[coinType].hasToppedUp = true;
  }
  db.persistUser(user);
  return coins[coinType].balance;
}

/**
 * Validasi order top up sebelum membuat invoice.
 */
function validateTopUp(coinType, amount) {
  const cfg = COIN_TYPES[coinType];
  if (!cfg) {
    return { valid: false, error: "Jenis koin tidak valid. Pilih: green, yellow, atau blue." };
  }
  const qty = Number(amount);
  if (!Number.isInteger(qty) || qty <= 0) {
    return { valid: false, error: "Jumlah koin harus berupa angka bulat positif." };
  }
  if (qty < cfg.minBuy) {
    return { valid: false, error: `Minimal pembelian koin ${cfg.label} adalah ${cfg.minBuy} koin.` };
  }
  const totalPrice = cfg.price * qty;
  if (totalPrice < 1000) {
    return { valid: false, error: "Nominal minimum pembayaran QRIS adalah Rp1.000." };
  }
  return { valid: true, totalPrice, coinType, amount: qty };
}

/**
 * Info koin lengkap untuk ditampilkan di frontend.
 */
function getCoinInfo(user) {
  const coins = processDailyRestock(user);
  const result = {};
  for (const type of ["green", "yellow", "blue"]) {
    const cfg = COIN_TYPES[type];
    const coin = coins[type];
    result[type] = {
      label: cfg.label,
      balance: coin.balance || 0,
      price: cfg.price,
      minBuy: cfg.minBuy,
      use: cfg.use,
      hasToppedUp: coin.hasToppedUp || false,
      dailyRestock: coin.hasToppedUp ? cfg.topUpRestock : cfg.dailyRestock,
    };
  }
  return result;
}

module.exports = {
  COIN_TYPES,
  getCoins,
  processDailyRestock,
  canAfford,
  consumeCoin,
  refundCoin,
  addCoins,
  validateTopUp,
  getCoinInfo,
  periodKey,
};