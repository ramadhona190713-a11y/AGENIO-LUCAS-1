// start.js — launcher: otomatis install dependency server HANYA kalau belum
// terpasang, lalu menjalankan server. Dipakai oleh `npm start`.
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const serverDir = path.join(__dirname, "server");
const REQUIRED = ["express", "cors", "jsonwebtoken", "qrcode", "socket.io", "pino", "@whiskeysockets/baileys"];

function missingDeps() {
  return REQUIRED.filter((name) => !fs.existsSync(path.join(serverDir, "node_modules", name, "package.json")));
}

let missing = missingDeps();
if (missing.length > 0) {
  console.log(`[Rzone] Dependency belum lengkap (${missing.join(", ")}). Menjalankan npm install...`);
  const npm = process.platform === "win32" ? "npm.cmd" : "npm";
  // cloudflared bersifat opsional (gagal di Termux/Android) -> kegagalannya tidak menghentikan install.
  const r = spawnSync(npm, ["install", "--omit=dev", "--no-audit", "--no-fund"], {
    cwd: serverDir,
    stdio: "inherit",
  });
  missing = missingDeps();
  if (missing.length > 0) {
    console.error(`[Rzone] Install gagal, paket belum ada: ${missing.join(", ")} (kode ${r.status}). Periksa koneksi internet lalu jalankan lagi.`);
    process.exit(1);
  }
  console.log("[Rzone] Install selesai.");
}

require("./server/src/index.js");
