// Tes sandbox WaroengPay. Jalankan dari folder server:
//   WP_KEY=wp_test_xxx node test-waroengpay.js
// Memakai key test (tanpa uang asli). Tidak menyentuh database asli:
// pembayaran hanya diuji lewat API gateway, bukan lewat db.
const KEY = process.env.WP_KEY || require("./config.json").waroengpay?.apiKey;
if (!KEY || !KEY.startsWith("wp_test_")) {
  console.error("Pakai key TEST: WP_KEY=wp_test_xxx node test-waroengpay.js");
  process.exit(1);
}
const BASE = "https://waroengpay.com";
const H = { Authorization: `Bearer ${KEY}`, "Content-Type": "application/json" };
const call = async (m, p, b, h) => {
  const r = await fetch(BASE + p, { method: m, headers: { ...H, ...(h || {}) }, body: b ? JSON.stringify(b) : undefined });
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; }
  return { s: r.status, j };
};
const ok = (c, m) => console.log((c ? "OK   " : "GAGAL") + " " + m);

(async () => {
  // 1. buat invoice
  let r = await call("POST", "/api/payments", { amount: 2000, reference: "TEST-" + Date.now(), description: "Top up koin Rzone", expires_in: 15 }, { "Idempotency-Key": "t" + Date.now() });
  ok(r.s === 201 && r.j.id, `create invoice -> ${r.s} id=${r.j.id}`);
  console.log("     field:", Object.keys(r.j).join(","));
  console.log("     status:", r.j.status, "| base_amount:", r.j.base_amount, "| amount:", r.j.amount, "| unique_code:", r.j.unique_code);
  console.log("     qris:", String(r.j.qris).slice(0, 30) + "...", "| pay_url:", r.j.pay_url, "| livemode:", r.j.livemode);
  const id = r.j.id; if (!id) process.exit(1);
  // 2. cek pending
  r = await call("GET", `/api/payments/${id}`); ok(r.j.status === "pending", `cek status -> ${r.j.status}`);
  // 3. simulate pay
  r = await call("POST", `/api/payments/${id}/simulate`, { action: "pay" }); ok(r.s === 200, `simulate pay -> ${r.s}`);
  r = await call("GET", `/api/payments/${id}`); ok(r.j.status === "paid" && r.j.base_amount === 2000, `setelah bayar -> ${r.j.status}, base_amount=${r.j.base_amount}`);
  // 4. cancel
  r = await call("POST", "/api/payments", { amount: 2000, reference: "TEST-C-" + Date.now() });
  const id2 = r.j.id; r = await call("POST", `/api/payments/${id2}/cancel`, {}); ok(r.s === 200, `cancel -> ${r.s}`);
  r = await call("GET", `/api/payments/${id2}`); ok(r.j.status === "cancelled", `setelah cancel -> ${r.j.status}`);
  // 5. cancel invoice yang sudah paid harus ditolak
  r = await call("POST", `/api/payments/${id}/cancel`, {}); ok(r.s === 409, `cancel invoice paid -> ${r.s} ${r.j.code || ""}`);
})().catch((e) => { console.error("ERROR", e.message); process.exit(1); });
