/**
 * Penyimpanan pesan sementara (in-memory) per grup, supaya bot bisa
 * mencari pesan yang memuat link tertentu untuk direaksi.
 *
 * SEKARANG BERBENTUK FACTORY (createMessageStore()) karena setiap akun
 * WhatsApp (bot controller MAUPUN setiap "sender" publik) butuh riwayat
 * pesannya SENDIRI-SENDIRI -- akun A cuma bisa mereaksi pesan yang memang
 * sudah tersinkron ke akun A (karena akun A anggota grup itu), begitu pula
 * akun B, dst. Kalau dipaksa satu Map global dibagi semua akun, pencarian
 * pesan jadi tidak akurat (bisa "ketemu" pesan yang sebenarnya tidak
 * pernah dilihat akun yang lagi mau mereaksi).
 */

const MAX_PER_GROUP = 200; // batasi memori, simpan 200 pesan terakhir per grup

function createMessageStore() {
  const store = new Map(); // groupId -> array of { key, text, timestamp }

  function addMessage(groupId, message) {
    const text =
      message.message?.conversation ||
      message.message?.extendedTextMessage?.text ||
      "";

    if (!text) return;

    if (!store.has(groupId)) store.set(groupId, []);
    const arr = store.get(groupId);

    arr.push({ key: message.key, text, timestamp: Date.now() });
    if (arr.length > MAX_PER_GROUP) arr.shift();
  }

  /**
   * Cari pesan (dari yang paling baru) yang memuat `link`, sambil
   * mengabaikan pesan tertentu (biasanya pesan .reactch itu sendiri,
   * supaya bot tidak "menemukan" command-nya sendiri sebagai target).
   */
  function findMessageByLink(groupId, link, excludeMessageId = null) {
    const arr = store.get(groupId) || [];
    for (let i = arr.length - 1; i >= 0; i--) {
      const item = arr[i];
      if (excludeMessageId && item.key.id === excludeMessageId) continue;
      if (item.text.includes(link)) return item;
    }
    return null;
  }

  /**
   * Cari pesan yang memuat `link` di SEMUA grup yang tersimpan (dipakai
   * oleh sender publik, yang tidak tahu/tidak perlu tahu ID grup spesifik
   * -- cukup tahu link-nya saja).
   */
  function findMessageByLinkAnyGroup(link) {
    for (const [groupId, arr] of store.entries()) {
      for (let i = arr.length - 1; i >= 0; i--) {
        if (arr[i].text.includes(link)) {
          return { groupId, message: arr[i] };
        }
      }
    }
    return null;
  }

  return { addMessage, findMessageByLink, findMessageByLinkAnyGroup };
}

module.exports = { createMessageStore };
