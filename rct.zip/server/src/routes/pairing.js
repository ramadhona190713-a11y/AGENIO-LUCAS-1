const express = require("express");
const router = express.Router();
const controllerBot = require("../controllerBot");
const senderPool = require("../senderPool");
const session = require("../session");

// ===================================================================
// 1. PAIRING BOT REACTCH (controller, opsional lewat config.json "botrc")
// ===================================================================

// GET /api/pairing/controller/status -> { enabled, connected }
// enabled=false berarti botrc dimatikan di config.json -> frontend akan
// menyembunyikan seluruh section "Pairing Bot Reactch".
router.get("/controller/status", (req, res) => {
  res.json(controllerBot.getStatus());
});

// POST /api/pairing/controller/qr -> tombol "Dapatkan QR" utk controller.
router.post("/controller/qr", async (req, res) => {
  try {
    if (!controllerBot.isEnabled()) {
      return res.status(400).json({ error: "botrc sedang dimatikan (false) di config.json." });
    }
    const status = controllerBot.getStatus();
    if (status.connected) {
      return res.json({ connected: true, qr: null });
    }
    await controllerBot.ensureStarted();
    res.json({ connected: false, qr: controllerBot.getLastQr() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================================================================
// 2. ADD SENDER PUBLIC (tidak terbatas, siapa pun boleh menambahkan)
// ===================================================================

// GET /api/pairing/senders -> daftar semua sender + jumlah yang aktif.
// Login TIDAK wajib untuk melihat daftar (biar siapa pun bisa cek jumlah
// sender aktif) -- tapi kalau sedang login, tiap sender dapat tambahan
// field `isMine` supaya frontend tahu tombol "Hapus" mana yang boleh
// ditampilkan (izin hapus yang sesungguhnya tetap dicek ulang di server,
// endpoint DELETE di bawah, bukan cuma mengandalkan field ini).
router.get("/senders", (req, res) => {
  const user = session.getSessionUser(req);
  const list = senderPool.listSenders(user?.id ?? null);
  res.json({ ok: true, senders: list, activeCount: senderPool.getActiveCount() });
});

// POST /api/pairing/senders -- WAJIB LOGIN (Google), supaya sender yang
// ditambahkan tercatat kepemilikannya dan cuma pemiliknya sendiri yang
// bisa menghapusnya nanti.
// body: { method: "qr" | "pairing", phoneNumber?: string, label?: string }
router.post("/senders", session.requireAuth, async (req, res) => {
  try {
    const { method, phoneNumber, label } = req.body || {};
    if (method !== "qr" && method !== "pairing") {
      return res.status(400).json({ error: "Field 'method' wajib 'qr' atau 'pairing'." });
    }
    if (method === "pairing" && !phoneNumber) {
      return res.status(400).json({ error: "Field 'phoneNumber' wajib diisi untuk metode pairing." });
    }
    const sender = await senderPool.createSender({ method, phoneNumber, label, ownerId: req.user.id });
    res.json({ ok: true, sender: { ...sender, isMine: true } });
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal menambahkan sender." });
  }
});

// DELETE /api/pairing/senders/:id -- WAJIB LOGIN, dan HANYA berhasil kalau
// yang login adalah pemilik sender tsb (dicek di senderPool.removeSender).
router.delete("/senders/:id", session.requireAuth, async (req, res) => {
  const result = await senderPool.removeSender(req.params.id, req.user.id);
  if (result === "not_found") return res.status(404).json({ error: "Sender tidak ditemukan." });
  if (result === "forbidden") {
    return res.status(403).json({ error: "Kamu bukan pemilik sender ini, tidak bisa menghapusnya." });
  }
  res.json({ ok: true });
});

module.exports = router;
