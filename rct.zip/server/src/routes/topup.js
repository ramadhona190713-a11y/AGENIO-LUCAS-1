const express = require("express");
const router = express.Router();
const session = require("../session");
const coins = require("../coins");
const payments = require("../payments");
const db = require("../db");
const { notifyAdmin } = require("../errorNotify");

// Semua endpoint top up WAJIB login
router.use(session.requireAuth);

/** Ambil order milik user yang sedang login, atau kirim error & return null. */
function getOwnOrder(req, res, reffId) {
  if (!reffId || typeof reffId !== "string") {
    res.status(400).json({ error: "Field 'reffId' wajib diisi." });
    return null;
  }
  const order = db.findOrder(reffId);
  if (!order) {
    res.status(404).json({ error: "Order tidak ditemukan." });
    return null;
  }
  if (order.userId !== req.user.id) {
    res.status(403).json({ error: "Bukan order kamu." });
    return null;
  }
  return order;
}

// GET /api/topup/info — info harga koin & saldo user
router.get("/info", (req, res) => {
  const coinInfo = coins.getCoinInfo(req.user);
  res.json({ ok: true, coins: coinInfo });
});

// POST /api/topup/order — buat order top up + invoice QRIS
// body: { coinType: "green"|"yellow"|"blue", amount: number }
router.post("/order", async (req, res) => {
  let reffId = null;
  try {
    const { coinType, amount } = req.body || {};

    if (!coinType || amount === undefined) {
      return res.status(400).json({ error: "Field 'coinType' dan 'amount' wajib diisi." });
    }

    const validation = coins.validateTopUp(coinType, Number(amount));
    if (!validation.valid) {
      return res.status(400).json({ error: validation.error });
    }

    const { totalPrice, amount: qty } = validation;
    reffId = payments.createOrder(req.user.id, coinType, qty, totalPrice);

    // Buat invoice di WaroengPay
    const invoiceResult = await payments.createInvoice(reffId, totalPrice);

    // Hasil ternormalisasi: { status: true|false, msg, data: {...} }
    if (!invoiceResult || invoiceResult.status === false || invoiceResult.error) {
      db.updateOrderStatus(reffId, "failed");
      const errMsg = invoiceResult?.msg || invoiceResult?.error || "Gagal membuat invoice pembayaran.";
      await notifyAdmin(`TopUp order GAGAL dibuat.\nUser: ${req.user.email}\nCoin: ${coinType} x${qty} (${totalPrice})\nReff: ${reffId}\nGateway response: ${JSON.stringify(invoiceResult)}`);
      return res.status(502).json({ error: String(errMsg) });
    }

    const data = invoiceResult.data || {};
    // Simpan ID invoice WaroengPay segera (dipakai cek status & cancel).
    db.updateOrderFields(reffId, { gatewayId: data.gateway_id });
    let qr = await payments.buildQrPayload(data);

    // Kalau respons pembuatan invoice tidak memuat QR, ambil dari cek status.
    if (!qr.qrImage) {
      try {
        const st = await payments.checkStatus(data.gateway_id);
        qr = await payments.buildQrPayload(st?.data || {});
      } catch (err) {
        console.error("[TopUp] Fallback ambil QR gagal:", err.message);
      }
    }

    if (!qr.qrImage && !qr.checkoutUrl) {
      await notifyAdmin(`TopUp: invoice dibuat tapi QR TIDAK ditemukan di respons.\nReff: ${reffId}\nRespons: ${JSON.stringify(invoiceResult)}`);
    }

    const totalBayar = Number(data.total_bayar ?? data.totalBayar ?? totalPrice) || totalPrice;
    const kodeUnik = Number(data.kode_unik ?? data.kodeUnik ?? totalBayar - totalPrice) || 0;
    const expiredAt = data.expired_at || data.expired || null;

    db.updateOrderFields(reffId, {
      totalBayar,
      kodeUnik,
      expiredAt,
      qrString: qr.qrString,
      qrUrl: qr.qrUrl,
      checkoutUrl: qr.checkoutUrl,
    });

    res.json({
      ok: true,
      reffId,
      coinType,
      amount: qty,
      totalPrice,
      totalBayar,
      kodeUnik,
      qrImage: qr.qrImage,
      qrUrl: qr.qrUrl,
      qrString: qr.qrString,
      checkoutUrl: qr.checkoutUrl,
      expiredAt,
    });
  } catch (err) {
    console.error("[TopUp] Error creating order:", err);
    if (reffId) db.updateOrderStatus(reffId, "failed");
    await notifyAdmin(`TopUp order ERROR.\nUser: ${req.user?.email}\nBody: ${JSON.stringify(req.body)}\nError: ${err.stack || err.message}`);
    res.status(500).json({ error: "Terjadi kesalahan saat membuat order." });
  }
});

// GET /api/topup/order/:reffId — detail pembayaran (dipakai untuk melanjutkan
// pembayaran order yang masih menunggu, mis. setelah halaman di-refresh)
router.get("/order/:reffId", async (req, res) => {
  try {
    const order = getOwnOrder(req, res, req.params.reffId);
    if (!order) return;

    const qr = await payments.buildQrPayload({
      qr_string: order.qrString,
      qr_url: order.qrUrl,
      checkout_url: order.checkoutUrl,
    });

    res.json({
      ok: true,
      reffId: order.reffId,
      status: order.status,
      coinType: order.coinType,
      amount: order.coinAmount,
      totalPrice: order.totalPrice,
      totalBayar: order.totalBayar ?? order.totalPrice,
      kodeUnik: order.kodeUnik ?? 0,
      expiredAt: order.expiredAt || null,
      ...qr,
    });
  } catch (err) {
    console.error("[TopUp] Error reading order:", err);
    res.status(500).json({ error: "Gagal memuat order." });
  }
});

// POST /api/topup/check — cek status pembayaran
// body: { reffId: string }
router.post("/check", async (req, res) => {
  try {
    const { reffId } = req.body || {};
    if (!getOwnOrder(req, res, reffId)) return;

    const result = await payments.processPaymentStatus(reffId);
    res.json({ ok: true, ...result });
  } catch (err) {
    console.error("[TopUp] Error checking status:", err);
    await notifyAdmin(`TopUp check ERROR.\nUser: ${req.user?.email}\nReff: ${req.body?.reffId}\nError: ${err.stack || err.message}`);
    res.status(500).json({ error: "Gagal mengecek status pembayaran." });
  }
});

// POST /api/topup/cancel — batalkan invoice
// body: { reffId: string }
router.post("/cancel", async (req, res) => {
  try {
    const { reffId } = req.body || {};
    const order = getOwnOrder(req, res, reffId);
    if (!order) return;

    if (order.status === "paid") return res.status(400).json({ error: "Order sudah dibayar, tidak bisa dibatalkan." });
    if (order.status === "cancelled") return res.json({ ok: true, message: "Invoice sudah dibatalkan." });

    if (order.status === "pending") {
      // Pastikan belum dibayar di sisi gateway sebelum dibatalkan.
      const current = await payments.processPaymentStatus(reffId);
      if (current.status === "paid") {
        return res.status(400).json({ error: "Order ternyata sudah dibayar, koin sudah ditambahkan." });
      }
      if (current.status === "pending") {
        const result = await payments.cancelInvoice(order.gatewayId);
        if (result?.status === false) {
          // Cek ulang: mungkin sudah kedaluwarsa di gateway (dianggap beres).
          const after = await payments.processPaymentStatus(reffId);
          if (after.status === "paid") {
            return res.status(400).json({ error: "Order ternyata sudah dibayar, koin sudah ditambahkan." });
          }
          if (after.status === "pending") {
            return res.status(502).json({ error: result.msg || "Gateway menolak pembatalan. Coba lagi." });
          }
        }
      }
    }

    db.updateOrderStatus(reffId, "cancelled");
    res.json({ ok: true, message: "Invoice dibatalkan." });
  } catch (err) {
    console.error("[TopUp] Error cancelling:", err);
    await notifyAdmin(`TopUp cancel ERROR.\nUser: ${req.user?.email}\nReff: ${req.body?.reffId}\nError: ${err.stack || err.message}`);
    res.status(500).json({ error: "Gagal membatalkan invoice." });
  }
});

// GET /api/topup/history — riwayat order user
router.get("/history", (req, res) => {
  const orders = db.getOrdersByUser(req.user.id).map((o) => ({
    reffId: o.reffId,
    coinType: o.coinType,
    coinAmount: o.coinAmount,
    totalPrice: o.totalPrice,
    status: o.status,
    createdAt: o.createdAt,
    paidAt: o.paidAt,
  }));
  res.json({ ok: true, orders });
});

module.exports = router;
