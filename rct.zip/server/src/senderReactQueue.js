/**
 * Antrian GLOBAL untuk reaksi dari pool SENDER PUBLIK. Beda dengan
 * reactQueue.js (yang jaraknya 15 detik, khusus melindungi SATU nomor
 * controller dari flood command ke grup), di sini jaraknya jauh lebih
 * pendek karena setiap sender adalah NOMOR BERBEDA yang cuma mengirim
 * SATU reaksi per request -- risiko kena limit anti-spam per nomor jauh
 * lebih kecil. Tetap diberi jeda kecil (0.5 detik) supaya reaksi tidak
 * "meledak" bersamaan dalam hitungan milidetik di satu postingan.
 */
const { createGlobalQueue } = require("./globalQueue");

const SENDER_REACT_SPACING_MS = 500;

module.exports = createGlobalQueue(SENDER_REACT_SPACING_MS);
