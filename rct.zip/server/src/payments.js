/**
 * Integrasi Payment Gateway WaroengPay (Dynamic QRIS).
 * Base URL: https://waroengpay.com
 *
 * Endpoints:
 *   POST /api/payments              — buat tagihan QRIS
 *   GET  /api/payments/:id          — cek status pembayaran
 *   POST /api/payments/:id/cancel   — batalkan invoice belum terbayar
 *
 * Auth: header "Authorization: Bearer <apiKey>" (config.waroengpay.apiKey).
 * wp_live_... = production, wp_test_... = sandbox.
 *
 * Catatan: WaroengPay membuat ID invoice sendiri (WRG-...). ID itu disimpan
 * di order lokal sebagai `gatewayId` dan dipakai untuk cek status / cancel.
 */

const crypto = require("crypto");
const QRCode = require("qrcode");
const config = require("../config.json");
const coins = require("./coins");
const db = require("./db");

const GATEWAY_BASE = "https://waroengpay.com";
const REQUEST_TIMEOUT_MS = 15000;
const INVOICE_EXPIRES_MINUTES = 15;

function getApiKey() {
  return config.waroengpay?.apiKey || "";
}

/**
 * Panggil WaroengPay. Selalu mengembalikan { ok, httpStatus, data } (tidak
 * pernah melempar karena body bukan JSON). Error gateway berbentuk
 * { error, code } di `data`.
 */
async function callGateway(method, path, body, extraHeaders) {
  const res = await fetch(`${GATEWAY_BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      "Content-Type": "application/json",
      ...(extraHeaders || {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });

  const raw = await res.text();
  try {
    return { ok: res.ok, httpStatus: res.status, data: JSON.parse(raw) };
  } catch {
    return {
      ok: false,
      httpStatus: res.status,
      data: { error: `Respons payment gateway tidak valid (HTTP ${res.status}).` },
    };
  }
}

/**
 * Ambil data QR dari respons gateway. Nama field bisa berbeda antar
 * endpoint/versi (qr_url, qris_url, qr_string, qris_string, ...), jadi
 * dicek semuanya -- ini penyebab QRIS tidak muncul sebelumnya: create_invoice
 * mengembalikan `qr_string`/`qr_url`, sementara kode lama hanya membaca
 * `qris_string`/`qris_url`.
 */
function pickFirst(obj, keys) {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === "string" && v.trim() !== "") return v.trim();
  }
  return null;
}

function extractQr(data) {
  const d = data && typeof data === "object" ? data : {};
  let qrString = pickFirst(d, ["qr_string", "qris_string", "qris", "qr_content", "qr_code", "qrcode", "emv"]);
  let qrUrl = pickFirst(d, ["qr_url", "qris_url", "qr_image", "qr_image_url", "qris_image", "image_url", "qr"]);

  // Beberapa gateway mengisi string EMV (000201...) ke field "url", atau
  // sebaliknya. Tukar kalau jelas salah tempat.
  if (qrUrl && /^0002\d{2}/.test(qrUrl) && !qrString) {
    qrString = qrUrl;
    qrUrl = null;
  }
  if (qrString && /^(https?:\/\/|data:image\/)/i.test(qrString) && !qrUrl) {
    qrUrl = qrString;
    qrString = null;
  }

  // URL relatif -> jadikan absolut ke domain gateway.
  if (qrUrl && qrUrl.startsWith("/")) {
    qrUrl = GATEWAY_BASE + qrUrl;
  }

  // Base64 mentah tanpa prefix data URL.
  if (qrUrl && /^[A-Za-z0-9+/=]{200,}$/.test(qrUrl)) {
    qrUrl = `data:image/png;base64,${qrUrl}`;
  }

  return {
    qrUrl,
    qrString,
    checkoutUrl: pickFirst(d, ["checkout_url", "payment_url", "pay_url", "url"]),
  };
}

/**
 * Ubah string QRIS (EMV) jadi gambar PNG (data URL) di server, jadi tidak
 * tergantung layanan pihak ketiga (api.qrserver.com) yang bisa diblokir
 * atau down.
 */
async function qrStringToDataUrl(qrString) {
  if (!qrString) return null;
  try {
    return await QRCode.toDataURL(qrString, { errorCorrectionLevel: "M", margin: 2, width: 420 });
  } catch (err) {
    console.error("[Payments] Gagal membuat gambar QR:", err.message);
    return null;
  }
}

/**
 * Bentuk objek QR siap-tampil untuk frontend: selalu usahakan ada `qrImage`
 * (gambar yang bisa langsung dipasang di <img src>).
 */
async function buildQrPayload(data) {
  const { qrUrl, qrString, checkoutUrl } = extractQr(data);
  let qrImage = qrUrl;
  if (!qrImage && qrString) qrImage = await qrStringToDataUrl(qrString);
  return { qrImage: qrImage || null, qrUrl, qrString, checkoutUrl };
}

/**
 * Ubah objek invoice WaroengPay ke bentuk data yang dipakai kode lain
 * (nama field: total_bayar, kode_unik, expired_at, qr_string, checkout_url).
 */
function normalizeInvoice(inv) {
  const i = inv && typeof inv === "object" ? inv : {};
  return {
    gateway_id: i.id || null,
    status: i.status || "",
    base_amount: i.base_amount ?? null,
    total_bayar: i.amount ?? null,
    kode_unik: i.unique_code ?? null,
    expired_at: i.expires_at || null,
    qr_string: i.qris || null,
    checkout_url: i.pay_url || null,
    livemode: i.livemode,
  };
}

function errorMessage(data, fallback) {
  return data?.error || fallback;
}

/**
 * Buat invoice QRIS di WaroengPay.
 * Mengembalikan { status: true, data } atau { status: false, msg }.
 */
async function createInvoice(reffId, nominal) {
  const r = await callGateway(
    "POST",
    "/api/payments",
    {
      amount: nominal,
      reference: reffId,
      description: "Top up koin Rzone",
      expires_in: INVOICE_EXPIRES_MINUTES,
    },
    { "Idempotency-Key": reffId }
  );
  if (!r.ok || !r.data?.id) {
    return { status: false, msg: errorMessage(r.data, "Gagal membuat invoice pembayaran."), raw: r.data };
  }
  return { status: true, data: normalizeInvoice(r.data) };
}

/**
 * Cek status pembayaran invoice (pakai ID invoice WaroengPay).
 */
async function checkStatus(gatewayId) {
  const r = await callGateway("GET", `/api/payments/${encodeURIComponent(gatewayId)}`);
  if (!r.ok || !r.data?.id) {
    return { status: false, msg: errorMessage(r.data, "Gagal mengecek status pembayaran."), raw: r.data };
  }
  return { status: true, data: normalizeInvoice(r.data) };
}

/**
 * Batalkan invoice yang belum dibayar (pakai ID invoice WaroengPay).
 */
async function cancelInvoice(gatewayId) {
  const r = await callGateway("POST", `/api/payments/${encodeURIComponent(gatewayId)}/cancel`, {});
  if (!r.ok) {
    return { status: false, msg: errorMessage(r.data, "Gagal membatalkan invoice."), code: r.data?.code };
  }
  return { status: true, data: normalizeInvoice(r.data) };
}

/**
 * Buat order top up lokal + simpan ke DB untuk tracking.
 */
function createOrder(userId, coinType, coinAmount, totalPrice) {
  const reffId = `RZ-${Date.now()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
  db.addOrder({
    reffId,
    userId,
    coinType,
    coinAmount,
    totalPrice,
    status: "pending",
    createdAt: new Date().toISOString(),
    paidAt: null,
  });
  return reffId;
}

function coinLabel(order) {
  return coins.COIN_TYPES[order.coinType]?.label || order.coinType;
}

function normalizeGatewayStatus(data) {
  return String(data?.status || "").toLowerCase();
}

const PAID_STATUSES = new Set(["paid"]);
const FAILED_STATUSES = new Set(["expired", "cancelled"]);

// Mencegah 2 pengecekan bersamaan (auto-check 4 detik + klik "Cek Status")
// sama-sama meng-credit koin untuk order yang sama.
const inFlight = new Map(); // reffId -> Promise

/**
 * Cek status pembayaran + credit koin kalau sudah paid.
 * Idempotent: kalau order sudah "paid" tidak akan credit ulang, termasuk
 * kalau dua request datang bersamaan.
 */
function processPaymentStatus(reffId) {
  if (inFlight.has(reffId)) return inFlight.get(reffId);
  const p = doProcessPaymentStatus(reffId).finally(() => inFlight.delete(reffId));
  inFlight.set(reffId, p);
  return p;
}

async function doProcessPaymentStatus(reffId) {
  const order = db.findOrder(reffId);
  if (!order) return { status: "not_found", message: "Order tidak ditemukan." };
  if (order.status === "paid") {
    return { status: "paid", message: `Pembayaran sudah selesai. +${order.coinAmount} koin ${coinLabel(order)}.` };
  }
  if (order.status === "cancelled") return { status: "cancelled", message: "Invoice sudah dibatalkan." };
  if (order.status === "expired") return { status: "expired", message: "Invoice sudah kedaluwarsa." };
  if (order.status === "failed") return { status: "expired", message: "Order gagal dibuat." };

  if (!order.gatewayId) {
    // Order lama (sebelum pindah gateway) atau invoice tidak pernah terbentuk.
    db.updateOrderStatus(reffId, "expired");
    return { status: "expired", message: "Invoice tidak ditemukan di gateway. Silakan buat order baru." };
  }

  let result;
  try {
    result = await checkStatus(order.gatewayId);
  } catch (err) {
    return { status: "error", message: "Gagal menghubungi payment gateway. Coba lagi." };
  }

  // Bentuk hasil (sudah dinormalisasi): { status: true, data: { status:
  // "pending"|"paid"|"expired"|"cancelled", base_amount, total_bayar, ... } }
  const data = result?.data || {};
  const gwStatus = normalizeGatewayStatus(data);

  if (PAID_STATUSES.has(gwStatus)) {
    // Pastikan nominal dasar invoice sama dengan harga order (cegah invoice
    // yang tidak cocok meng-credit koin).
    if (data.base_amount !== null && Number(data.base_amount) !== Number(order.totalPrice)) {
      console.error(`[Payments] base_amount tidak cocok untuk ${reffId}: gateway=${data.base_amount} order=${order.totalPrice}`);
      return { status: "error", message: "Nominal pembayaran tidak cocok dengan order. Hubungi admin." };
    }
    // Re-baca order setelah await, jaga-jaga status berubah selama menunggu.
    const fresh = db.findOrder(reffId);
    if (fresh && fresh.status !== "paid") {
      coins.addCoins(fresh.userId, fresh.coinType, fresh.coinAmount);
      db.updateOrderStatus(reffId, "paid");
    }
    return {
      status: "paid",
      message: `Pembayaran berhasil! +${order.coinAmount} koin ${coinLabel(order)} sudah masuk.`,
    };
  }

  if (FAILED_STATUSES.has(gwStatus)) {
    db.updateOrderStatus(reffId, "expired");
    return { status: "expired", message: "Pembayaran gagal atau kedaluwarsa." };
  }

  if (result?.status === false && !gwStatus) {
    // Gateway menjawab error (mis. gangguan sementara / rate limit).
    return { status: "pending", message: result?.msg || "Menunggu pembayaran..." };
  }

  const qr = await buildQrPayload(data);
  return {
    status: "pending",
    message: "Menunggu pembayaran...",
    ...qr,
    totalBayar: data.total_bayar ?? order.totalPrice,
  };
}

module.exports = {
  createInvoice,
  checkStatus,
  cancelInvoice,
  createOrder,
  processPaymentStatus,
  extractQr,
  buildQrPayload,
};
