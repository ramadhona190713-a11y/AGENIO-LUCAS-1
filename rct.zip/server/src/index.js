const express = require("express");
const http = require("http");
const path = require("path");
const cors = require("cors");
const { Server } = require("socket.io");

const config = require("../config.json");
const controllerBot = require("./controllerBot");
const senderPool = require("./senderPool");
const tunnel = require("./tunnel");
const systemStatus = require("./systemStatus");
const { createTelegramBot } = require("./telegramBot");

const pairingRoutes = require("./routes/pairing");
const reactRoutes = require("./routes/react");
const devRoutes = require("./routes/dev");
const authRoutes = require("./routes/auth");
const topupRoutes = require("./routes/topup");

const app = express();
app.set("trust proxy", true);
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/pairing", pairingRoutes);
app.use("/api/react", reactRoutes);
app.use("/api/dev", devRoutes);
app.use("/api/topup", topupRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true, bot: config.botName }));

// === SERVE FRONTEND ===
const CLIENT_PUBLIC = path.join(__dirname, "..", "..", "client", "public");

app.use((req, res, next) => {
  if (!systemStatus.isBlocked()) return next();
  if (req.path.startsWith("/api")) return next();
  if (req.path.startsWith("/css/") || req.path.startsWith("/js/")) return next();
  if (/\.[a-zA-Z0-9]+$/.test(req.path) && !req.path.endsWith(".html")) return next();

  const pageFile = systemStatus.blockedPageFile();
  return res.status(503).sendFile(path.join(CLIENT_PUBLIC, pageFile));
});

app.use(express.static(CLIENT_PUBLIC, { extensions: ["html"] }));

app.get(/^(?!\/api).*/, (req, res) => {
  res.status(404).sendFile(path.join(CLIENT_PUBLIC, "404.html"), (err) => {
    if (err) {
      res.status(404).send("Halaman tidak ditemukan.");
    }
  });
});

app.use((err, req, res, next) => {
  console.error("[Rzone] Unhandled error:", err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: "Terjadi kesalahan pada server." });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

controllerBot.setSocketIo(io);
senderPool.setSocketIo(io);

io.on("connection", (socket) => {
  socket.emit("controller:connected", controllerBot.getStatus());
  const qr = controllerBot.getLastQr();
  if (qr) socket.emit("controller:qr", { qr });
  senderPool.listSenders().forEach((s) => socket.emit("sender:update", s));
});

server.listen(config.port, () => {
  console.log(`[Rzone] Server jalan di http://localhost:${config.port}`);

  if (config.botrc === true) {
    controllerBot.ensureStarted().catch((err) => {
      console.error("[Rzone][Controller] Gagal start otomatis:", err.message);
    });
  } else {
    console.log('[Rzone] botrc=false -> controller tidak dijalankan.');
  }

  senderPool.reconnectAllFromRegistry().catch((err) => {
    console.error("[Rzone] Gagal menyambungkan ulang sender:", err.message);
  });

  tunnel.startTunnel().catch((err) => {
    console.error("[Rzone] Gagal start tunnel:", err.message);
  });
  createTelegramBot(config).start();
});

function shutdown() {
  console.log("[Rzone] Mematikan server & tunnel...");
  tunnel.stopTunnel();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

process.on("unhandledRejection", (reason) => {
  console.error("[Rzone] Unhandled promise rejection:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("[Rzone] Uncaught exception:", err);
});