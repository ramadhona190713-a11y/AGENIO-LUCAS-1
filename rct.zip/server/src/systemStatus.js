/**
 * Status sistem "close/open" & "maintenance/selesai-maintenance", dikontrol
 * ADMIN lewat Telegram (lihat telegramBot.js -> /close /open /m /sm).
 *
 * DUA FLAG INDEPENDEN, tersimpan di db.json supaya tetap nyala walau server
 * di-restart (tidak ke-reset ke "terbuka" begitu saja):
 *   - closed      : diaktifkan /close, dimatikan /open
 *   - maintenance : diaktifkan /m,     dimatikan /sm
 *
 * Kalau SALAH SATU aktif, seluruh jalur react (web, API developer, controller
 * .reactch) diblokir total -- lihat pemakaiannya di index.js, routes/react.js,
 * routes/dev.js, dan controllerBot.js. Tidak ada bedanya secara TEKNIS antara
 * "closed" dan "maintenance"; bedanya cuma PESAN yang ditampilkan ke user.
 */

const db = require("./db");

const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb8TfRj5Ui2Pby1ezb0O";

function getStatus() {
  return db.getSystemStatus();
}

function isClosed() {
  return db.getSystemStatus().closed === true;
}

function isMaintenance() {
  return db.getSystemStatus().maintenance === true;
}

/** true kalau salah satu (atau keduanya) aktif -> semua jalur react harus diblokir. */
function isBlocked() {
  return isClosed() || isMaintenance();
}

function setClosed(value) {
  db.setClosed(value === true);
}

function setMaintenance(value) {
  db.setMaintenance(value === true);
}

/** Pesan singkat (untuk balasan JSON API / controller), null kalau tidak diblokir. */
function blockedMessage() {
  if (isClosed()) {
    return (
      "Website sedang DITUTUP sementara. Tunggu sampai besok untuk info waktu & " +
      `selengkapnya di: ${WHATSAPP_CHANNEL_URL}`
    );
  }
  if (isMaintenance()) {
    return "Sedang MAINTENANCE, semua fitur react sementara tidak bisa dipakai. Coba lagi nanti.";
  }
  return null;
}

/** Nama file HTML yang harus disajikan di web selama diblokir, null kalau tidak. */
function blockedPageFile() {
  if (isClosed()) return "closed.html";
  if (isMaintenance()) return "maintenance.html";
  return null;
}

module.exports = {
  WHATSAPP_CHANNEL_URL,
  getStatus,
  isClosed,
  isMaintenance,
  isBlocked,
  setClosed,
  setMaintenance,
  blockedMessage,
  blockedPageFile,
};
