/**
 * Kirim notifikasi error ke admin via Telegram.
 * Dipakai oleh route topup / payments supaya setiap error langsung
 * dikirim ke chat admin (config.telegramBot.adminChatIds).
 */

const config = require("../config.json");

async function notifyAdmin(message) {
  try {
    const cfg = config?.telegramBot;
    if (!cfg || !cfg.enabled || !cfg.botToken || !Array.isArray(cfg.adminChatIds) || cfg.adminChatIds.length === 0) {
      return;
    }
    for (const id of cfg.adminChatIds) {
      await fetch(`https://api.telegram.org/bot${cfg.botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: id,
          text: `[Rzone Error]\n${new Date().toISOString()}\n\n${message}`,
        }),
      });
    }
  } catch (err) {
    console.error("[notifyAdmin] gagal kirim:", err.message);
  }
}

module.exports = { notifyAdmin };