# Dokumentasi API — Rzone WA Bot (Mode Developer, Sistem Koin)

## Autentikasi

Setiap request API membutuhkan header:
```
x-api-key: rzone_...xxxx
```

API key didapat setelah login Google di halaman `/developer`.

## Koin Biru (API)

- Setiap request `POST /api/dev/react` memakai **1 Koin Biru**.
- Restock otomatis **10 koin/hari** jam 00:00 WIB.
- Kalau habis, request ditolak (HTTP 402) sampai top up atau restock berikutnya.
- Top up koin Biru: Rp700/koin, minimal 5 koin (via halaman web `/topup`).

## Endpoint

### POST /api/dev/react

```
Headers:
  Content-Type: application/json
  x-api-key: rzone_...xxxx

Body:
{
  "link": "https://whatsapp.com/channel/xxxxx/123",
  "emojis": ["emoji1", "emoji2", "emoji3"]
}
```

Response sukses (200):
```json
{ "ok": true, "success": true, "refunded": false, "reactions": 4 }
```

`reactions` = jumlah reaksi yang berhasil terkirim. Kalau `success` false, koin otomatis dikembalikan (`refunded: true`).

Response koin habis (402):
```json
{ "error": "Koin Biru habis. Top up dulu untuk melanjutkan.", "needTopUp": true, "coinType": "blue" }
```

Response tidak ada sender (503):
```json
{ "error": "Tidak ada sender WhatsApp yang aktif saat ini. Request tidak bisa diproses." }
```

Header response: `X-Blue-Coins-Remaining` menunjukkan sisa koin biru.

### GET /api/dev/me

Butuh sesi login Google (cookie). Return API key + info koin.

### POST /api/dev/regenerate

Butuh sesi login. Ganti API key baru (key lama langsung invalid).

### GET /api/dev/stats

Butuh sesi login. Return saldo koin + riwayat request.

## Cara Kerja React

- Setiap **sender aktif** memilih 1 emoji ACAK dari daftar, lalu mereaksi.
- Jumlah reaksi = jumlah sender aktif.
- Kalau tidak ada sender aktif (dan controller off), request ditolak 503.
- Koin Biru dipotong SEBELUM eksekusi (kalau gagal di tengah, koin tetap terpotong).