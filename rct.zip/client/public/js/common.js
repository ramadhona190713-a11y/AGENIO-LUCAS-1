// common.js — shared across all pages.
// Handles: bottom nav highlight, sender status dot, auth module.
(function () {
  const path = window.location.pathname.replace(/\/index\.html$/, "/");

  document.querySelectorAll(".bottom-nav a[href]").forEach((a) => {
    const href = a.getAttribute("href");
    const isActive = href === path || (href === "/" && path === "/");
    a.classList.toggle("active", isActive);
  });

  // Status dot: active senders
  const dot = document.getElementById("statusDot");
  function setStatusDot(activeCount) {
    if (!dot) return;
    dot.classList.remove("on", "off");
    dot.classList.add(activeCount > 0 ? "on" : "off");
    dot.title = activeCount > 0 ? `${activeCount} sender aktif` : "Tidak ada sender aktif";
  }

  fetch("/api/pairing/senders")
    .then((r) => r.json())
    .then((d) => setStatusDot(d.activeCount || 0))
    .catch(() => {});

  if (window.io) {
    const socket = window.io("/", { path: "/socket.io" });
    const refreshCount = () => {
      fetch("/api/pairing/senders")
        .then((r) => r.json())
        .then((d) => setStatusDot(d.activeCount || 0))
        .catch(() => {});
    };
    socket.on("sender:update", refreshCount);
    socket.on("sender:removed", refreshCount);
    window.__rzoneSocket = socket;
  }

  // === Auth module ===
  let currentUser = null;

  async function fetchMe() {
    try {
      const res = await fetch("/api/auth/me");
      if (!res.ok) { currentUser = null; return null; }
      currentUser = await res.json();
      return currentUser;
    } catch { currentUser = null; return null; }
  }

  function getUser() { return currentUser; }
  function loginUrl() { return "/api/auth/google/start"; }

  async function logout() {
    try { await fetch("/api/auth/logout", { method: "POST" }); } catch {}
    currentUser = null;
    window.location.reload();
  }

  window.RzoneAuth = { fetchMe, getUser, logout, loginUrl };
})();