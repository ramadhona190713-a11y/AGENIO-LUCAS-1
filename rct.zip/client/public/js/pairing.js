// pairing.js — Pairing page logic (controller + sender public).
(function () {
  // === Controller ===
  const controllerSection = document.getElementById("controllerSection");
  const checkingText = document.getElementById("checkingText");
  const notConnectedSection = document.getElementById("notConnectedSection");
  const getQrBtn = document.getElementById("getQrBtn");
  const waitingBox = document.getElementById("waitingBox");
  const qrBox = document.getElementById("qrBox");
  const qrImg = document.getElementById("qrImg");
  const errorBox = document.getElementById("errorBox");
  const errorText = document.getElementById("errorText");

  async function initController() {
    try {
      const res = await fetch("/api/pairing/controller/status");
      const data = await res.json();
      if (!data.enabled) { controllerSection.hidden = true; return; }
      if (data.connected) { controllerSection.hidden = true; return; }
      controllerSection.hidden = false;
      checkingText.hidden = true;
      notConnectedSection.hidden = false;
    } catch { controllerSection.hidden = true; }
  }

  getQrBtn?.addEventListener("click", async () => {
    errorBox.hidden = true;
    getQrBtn.disabled = true;
    waitingBox.hidden = false;
    try {
      const res = await fetch("/api/pairing/controller/qr", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal memulai pairing.");
      if (data.connected) { controllerSection.hidden = true; return; }
      if (data.qr) { qrImg.src = data.qr; qrBox.hidden = false; }
    } catch (err) {
      errorText.textContent = err.message;
      errorBox.hidden = false;
    } finally {
      waitingBox.hidden = true;
      getQrBtn.disabled = false;
    }
  });

  if (window.__rzoneSocket) {
    window.__rzoneSocket.on("controller:qr", (data) => {
      if (!data.qr) return;
      qrImg.src = data.qr;
      qrBox.hidden = false;
      waitingBox.hidden = true;
    });
    window.__rzoneSocket.on("controller:connected", (data) => {
      if (data.connected) controllerSection.hidden = true;
    });
  }

  initController();

  // === Sender Public ===
  const activeSenderCountText = document.getElementById("activeSenderCountText");
  const addSenderBtn = document.getElementById("addSenderBtn");
  const senderLoginHint = document.getElementById("senderLoginHint");
  const addSenderForm = document.getElementById("addSenderForm");
  const methodButtons = document.querySelectorAll("#addSenderForm .segment button");
  const phoneField = document.getElementById("phoneField");
  const senderPhoneInput = document.getElementById("senderPhone");
  const submitAddSenderBtn = document.getElementById("submitAddSenderBtn");
  const addSenderError = document.getElementById("addSenderError");
  const addSenderErrorText = document.getElementById("addSenderErrorText");
  const senderListEmpty = document.getElementById("senderListEmpty");
  const senderList = document.getElementById("senderList");

  let currentMethod = "qr";
  let isLoggedIn = false;
  const sendersMap = new Map();

  addSenderBtn?.addEventListener("click", () => {
    if (!isLoggedIn) { window.location.href = "/api/auth/google/start"; return; }
    addSenderForm.hidden = !addSenderForm.hidden;
    addSenderError.hidden = true;
  });

  methodButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      methodButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentMethod = btn.dataset.method;
      phoneField.hidden = currentMethod !== "pairing";
    });
  });

  function statusLabel(status) {
    switch (status) {
      case "connected": return "Aktif";
      case "qr": return "Menunggu scan QR";
      case "waiting_pairing_code": return "Menunggu kode";
      case "connecting": return "Menyambungkan...";
      case "disconnected": return "Terputus";
      case "error": return "Gagal";
      default: return status;
    }
  }

  function renderSenderList() {
    const items = Array.from(sendersMap.values());
    activeSenderCountText.textContent = items.filter((s) => s.status === "connected").length;
    if (items.length === 0) { senderListEmpty.hidden = false; senderList.innerHTML = ""; return; }
    senderListEmpty.hidden = true;
    senderList.innerHTML = "";
    items.forEach((s) => {
      const card = document.createElement("div");
      card.style.cssText = "border:1px solid var(--border); border-radius:var(--radius-sm); padding:12px; margin-bottom:8px;";
      const head = document.createElement("div");
      head.style.cssText = "display:flex; justify-content:space-between; align-items:center; gap:8px;";
      const label = document.createElement("span");
      const nameEl = document.createElement("b");
      nameEl.textContent = s.phoneNumber || s.label || s.id;
      const statusEl = document.createElement("span");
      statusEl.style.cssText = "font-size:12px;color:var(--ink-secondary)";
      statusEl.textContent = statusLabel(s.status) + (s.status === "error" && s.error ? ` — ${s.error}` : "");
      label.append(nameEl, document.createElement("br"), statusEl);
      const removeBtn = document.createElement("button");
      removeBtn.className = "btn btn-red btn-sm";
      removeBtn.textContent = "Hapus";
      removeBtn.addEventListener("click", () => removeSender(s.id));
      head.appendChild(label);
      if (s.isMine) head.appendChild(removeBtn);
      card.appendChild(head);
      if (s.status === "qr" && s.qr) {
        // insertAdjacentHTML (bukan innerHTML +=) supaya listener tombol Hapus tidak hilang
        const box = document.createElement("div");
        box.className = "qr-box";
        box.style.marginTop = "10px";
        const img = document.createElement("img");
        img.alt = "QR";
        img.style.maxWidth = "180px";
        img.src = s.qr;
        const p = document.createElement("p");
        p.textContent = "Scan QR";
        box.append(img, p);
        card.appendChild(box);
      }
      if (s.status === "waiting_pairing_code" && s.pairingCode) {
        const box = document.createElement("div");
        box.className = "alert alert-info";
        box.style.marginTop = "10px";
        const span = document.createElement("span");
        span.append("Kode: ");
        const code = document.createElement("b");
        code.style.letterSpacing = "2px";
        code.textContent = s.pairingCode;
        span.appendChild(code);
        box.appendChild(span);
        card.appendChild(box);
      }
      senderList.appendChild(card);
    });
  }

  async function removeSender(id) {
    try {
      const res = await fetch(`/api/pairing/senders/${encodeURIComponent(id)}`, { method: "DELETE" });
      if (!res.ok) { const d = await res.json(); alert(d.error || "Gagal hapus."); return; }
      sendersMap.delete(id);
      renderSenderList();
    } catch { alert("Gagal hapus sender."); }
  }

  submitAddSenderBtn?.addEventListener("click", async () => {
    addSenderError.hidden = true;
    const phone = senderPhoneInput.value.trim();
    if (currentMethod === "pairing" && !phone) {
      addSenderErrorText.textContent = "Isi nomor WhatsApp.";
      addSenderError.hidden = false;
      return;
    }
    submitAddSenderBtn.disabled = true;
    submitAddSenderBtn.textContent = "Menghubungkan...";
    try {
      const res = await fetch("/api/pairing/senders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: currentMethod, phoneNumber: phone || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal.");
      sendersMap.set(data.sender.id, data.sender);
      renderSenderList();
      senderPhoneInput.value = "";
      addSenderForm.hidden = true;
    } catch (err) {
      addSenderErrorText.textContent = err.message;
      addSenderError.hidden = false;
    } finally {
      submitAddSenderBtn.disabled = false;
      submitAddSenderBtn.textContent = "Hubungkan";
    }
  });

  if (window.__rzoneSocket) {
    window.__rzoneSocket.on("sender:update", () => initSenders());
    window.__rzoneSocket.on("sender:removed", ({ id }) => { sendersMap.delete(id); renderSenderList(); });
  }

  async function initSenders() {
    try {
      const res = await fetch("/api/pairing/senders");
      const data = await res.json();
      sendersMap.clear();
      (data.senders || []).forEach((s) => sendersMap.set(s.id, s));
      renderSenderList();
    } catch { renderSenderList(); }
  }

  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    isLoggedIn = Boolean(user && user.ok);
    senderLoginHint.hidden = isLoggedIn;
    await initSenders();
  })();
})();