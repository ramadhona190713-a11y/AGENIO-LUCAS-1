# Rzone WA Bot — Sistem Koin

Website + Bot WhatsApp (pairing via QR/pairing code) dengan fitur auto-react
link saluran, **sistem koin** (Hijau/Kuning/Biru), payment QRIS via WaroengPay,
dan UI modern clean.

## Sistem Koin

| Koin | Fungsi | Restock | Harga Top Up | Min Beli |
|------|--------|---------|--------------|----------|
| Hijau | React via web | 2/hari (4/hari setelah pernah top up) | Rp500 | 4 |
| Kuning | React via web | Tidak ada | Rp150 | 10 |
| Biru | Khusus API | 10/hari | Rp700 | 5 |

- Restock terjadi otomatis jam **00:00 WIB**.
- Di halaman react web, user **bisa pilih** pakai koin Hijau atau Kuning.
- API developer **selalu** pakai koin Biru.
- 1 koin = 1 request react.

## Payment (QRIS via WaroengPay)

- Auto-check status pembayaran tiap **4 detik**.
- Tombol **Cek Status** manual + **Batal** tersedia.
- Base URL: `https://waroengpay.com`
- Auth: header `Authorization: Bearer <apiKey>` (`wp_live_...` production, `wp_test_...` sandbox)
- Invoice dibuat via `POST /api/payments`, status dicek via `GET /api/payments/:id`, batal via `POST /api/payments/:id/cancel`

## Struktur Proyek

```
rzone-wa-bot/
├── server/          -> Backend Node.js (Express + Baileys + Socket.io)
│   ├── config.json  -> Konfigurasi (port, Google OAuth, WaroengPay, Telegram bot)
│   └── src/
│       ├── index.js         -> Entry point
│       ├── coins.js         -> Sistem koin (green/yellow/blue)
│       ├── payments.js      -> Integrasi WaroengPay QRIS
│       ├── db.js            -> Database JSON (users, orders, logs, senders)
│       ├── accounts.js      -> Manajemen akun
│       ├── session.js       -> JWT session (cookie httpOnly)
│       ├── googleAuth.js    -> Google OAuth
│       ├── routes/
│       │   ├── react.js     -> POST /api/react (web, pilih koin hijau/kuning)
│       │   ├── dev.js       -> POST /api/dev/react (API, koin biru)
│       │   ├── topup.js     -> Top up koin + QRIS payment
│       │   ├── auth.js      -> Google login/logout
│       │   └── pairing.js   -> Pairing sender/controller
│       ├── senderPool.js    -> Pool sender WhatsApp publik
│       ├── controllerBot.js -> Bot controller .reactch (opsional)
│       ├── reactEngine.js   -> Eksekusi react
│       ├── telegramBot.js   -> Bot Telegram admin
│       └── ...
└── client/
    └── public/      -> Frontend statis (HTML/CSS/JS, tanpa build)
        ├── index.html       -> Home (auto react + pilih koin)
        ├── topup.html       -> Top up koin + QRIS
        ├── pairing.html     -> Pairing sender
        ├── developer.html   -> API key + statistik
        ├── account.html     -> Info akun + saldo koin
        ├── css/style.css    -> UI baru (clean modern)
        └── js/              -> Logic per halaman
```

## Cara Jalankan

```bash
cd server
npm install
npm start
```

Server jalan di `http://localhost:3000` (serve API + frontend statis).

## Config (server/config.json)

```json
{
  "port": 3000,
  "botrc": true,
  "publicBaseUrl": "https://domain-kamu.com",
  "googleClientId": "...",
  "googleClientSecret": "...",
  "developerMode": { "jwtSecret": "..." },
  "waroengpay": { "apiKey": "wp_live_..." },
  "telegramBot": { "enabled": true, "botToken": "...", "adminChatIds": [123] }
}
```

## Telegram Admin Bot

Command tersedia:
- `/accounts` — daftar akun + saldo koin
- `/account <email>` — detail akun
- `/addcoins <email> <green|yellow|blue> <jumlah>` — tambah koin manual
- `/senders` — daftar sender
- `/close` `/open` `/m` `/sm` — tutup/maintenance
- `/reacthariini` `/leaderboard` — statistik

## Catatan

- Menggunakan **Baileys** (library WhatsApp tidak resmi). Risiko ban nomor.
- Login wajib via **Google OAuth** (tidak ada mode anonim).
- Data disimpan di `server/src/data/rzone-db.json` (JSON sync, atomik).
- Cloudflared tunnel auto-start bareng server (kalau token valid).